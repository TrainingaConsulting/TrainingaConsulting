﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class InfoFeedBack : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        hdns.Value = Session.SessionID;
    }

    [System.Web.Services.WebMethod]
    public static string InsertAndClose(string session, String txtEbook, String txtFeedBackGood, String txtFeedBackBad, String txtContact, String Checked)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            FeedBack fb = new FeedBack();

            fb.SessionId = session;
            fb.EbookEmail = txtEbook;
            fb.FeedBackGood = txtFeedBackGood;
            fb.FeedBackBad = txtFeedBackBad;
            fb.ContactEmail = txtContact;

            if (Checked == "true")
            {
                fb.Suhlas = true;
            }
            else
            {
                fb.Suhlas = false;
            }
            fb.DateInserted = DateTime.Now;
            dt.FeedBacks.InsertOnSubmit(fb);
            dt.SubmitChanges();
        }
        return "";
    }

}