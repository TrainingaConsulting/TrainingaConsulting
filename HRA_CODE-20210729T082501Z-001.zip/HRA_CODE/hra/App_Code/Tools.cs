﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Tools
/// </summary>
public static class Tools
{
    public static void RestartCache()
    {
        using (DataClassesSetupDataContext dt = new DataClassesSetupDataContext())
        {
            var setup = (from a in dt.GameSetups
                     where a.Name == "RestartCache"
                     select a).FirstOrDefault();

            if (setup != null)
            {
                setup.Value = "1";
            }
            dt.SubmitChanges();
        }
    }

    public static void AddEventNotification(string SessionID, int Period, String Nazov, String Popis, string KodProduktu)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            HracNotifikacie not = new HracNotifikacie();
            not.SessionId = SessionID;
            not.CurrentPeriod = Period;
            not.Nazov = Nazov;
            not.Popis = Popis;
            not.DatumZapisu = DateTime.Now;
            not.Informovany = false;
            not.KodProduktu = KodProduktu;
            dt.HracNotifikacies.InsertOnSubmit(not);
            dt.SubmitChanges();
        }
    }
    public static void AddFinancialNotification(string SessionID, int Period, String Nazov, String Popis, string KodProduktu, decimal Suma, bool PeriodickaPlatba)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            HracPlatby Pay = new HracPlatby();
            Pay.SessionId = SessionID;
            Pay.CurrentPeriod = Period;
            Pay.Nazov = Nazov;
            Pay.Popis = Popis;
            Pay.DatumZapisu = DateTime.Now;
            Pay.Informovany = false;
            Pay.Suma = Suma;
            Pay.Periodic = PeriodickaPlatba;
            Pay.KodProduktu = KodProduktu;
            Pay.Active = true;

            dt.HracPlatbies.InsertOnSubmit(Pay);

            dt.SubmitChanges();
        }

    }
    /// <summary>
    ///     
    /// </summary>
    /// <param name="SessionId"></param>
    /// <param name="TargetID">Except target id</param>
    public static bool HracMaMajetok(string SessionId, int TargetID)
    {
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(SessionId);
        return HracMaMajetok(SessionId, _fch, TargetID);
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="SessionId"></param>
    /// <param name="FinCache"></param>
    /// <param name="TargetID">Except target id</param>
    public static bool HracMaMajetok(string SessionId, FinCache.FinCache FinCache, int TargetID)
    {
        FinCache.FinCache _fch = FinCache;
        UserStatus _status = new UserStatus(SessionId);
        return HracMaMajetok(_status, _fch, TargetID);
    }
    /// <summary>
    /// 
    /// </summary>
    /// <param name="User"></param>
    /// <param name="FinCache"></param>
    /// <param name="TargetID">Except target id</param>
    /// <returns></returns>
    public static bool HracMaMajetok(UserStatus User, FinCache.FinCache FinCache, int TargetID)
    {
        bool ret = false;
        FinCache.FinCache _fch = FinCache;
        UserStatus _status = User;

        if (TargetID != 1)
        {
            if (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == _status.ST.Ciel1Id).FirstOrDefault().Type == "Nehnuteľnost")
            {
                if (_status.ST.SplnenyCiel1 == true)
                {
                    ret = true;
                }
            }
        }
        if (TargetID != 2)
        {
            if (ret == false)
            {
                if (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == _status.ST.Ciel2Id).FirstOrDefault().Type == "Nehnuteľnost")
                {
                    if (_status.ST.SplnenyCiel2 == true)
                    {
                        ret = true;
                    }
                }
            }
        }
        if (TargetID != 3)
        {
            if (ret == false)
            {
                if (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == _status.ST.Ciel3Id).FirstOrDefault().Type == "Nehnuteľnost")
                {
                    if (_status.ST.SplnenyCiel3 == true)
                    {
                        ret = true;
                    }
                }
            }
        }
        return ret;
    }
}