﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Udalosti
/// </summary>
public class Udalosti
{
    private List<FinCache.Udalost> _Udalosti;
    private FinCache.FinCache _fch = null;
    UserStatus _status = null;
    private StavHracaUdalosti _ud = null;
    public FinCache.Udalost _NahodnaUdalost = null;
    public FinCache.Udalost _SpecificUdalost = null;
    private bool insured = false;

    public bool Insured
    {
        get { return insured; }
    }
    private string _session;
    public Udalosti()
    {
        _Udalosti = new List<FinCache.Udalost>();
        _fch = FinCache.FinCache.GetInstance();
        CleanUdalosti();
        PickRandomUdalost();

    }
    public Udalosti(String SessionId)
    {
        _Udalosti = new List<FinCache.Udalost>();
        _session = SessionId;
        _status = new UserStatus(_session);
        _fch = FinCache.FinCache.GetInstance();
        CleanUdalosti();
        PickRandomUdalost();

    }

    public Udalosti(String SessionId, Boolean ForRecalc)
    {
        _Udalosti = new List<FinCache.Udalost>();
        _session = SessionId;
        _status = new UserStatus(_session);
        _fch = FinCache.FinCache.GetInstance();
        CleanUdalosti();
    }
    public Udalosti(String SessionId, string KodUdalosti)
    {
        _Udalosti = new List<FinCache.Udalost>();
        _session = SessionId;
        _status = new UserStatus(_session);
        _fch = FinCache.FinCache.GetInstance();
        _SpecificUdalost = (from a in _fch.FinUdalost
                           where a.kod == KodUdalosti
                           select a).FirstOrDefault<FinCache.Udalost>();
    }
    private void CleanUdalosti()
    {
        _Udalosti.AddRange(_fch.FinUdalost);
    }

    public void ProcessCurrentUdalost()
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            _ud = dt.GetUserUdalost(_session, _status.ST.CurrentPeriod).FirstOrDefault();
        }
        _NahodnaUdalost = _fch.FinUdalost.Select(u => u).Where(udd => udd.id == _ud.idUdalosti).FirstOrDefault();
        if (_ud.Ano)
        {
            CalculateActualEvent();
            CalculateAtualProperies();
            //_status.saveHistory();
            _status.SaveUserStatus();
        }
        if (_ud.Kod == "dedicstvo")
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                var _ud2 = dt.GetUserUdalost(_session, _status.ST.CurrentPeriod).FirstOrDefault();
                if (_ud.Ano == true)
                {
                    _ud2.Ano = false;
                }
                else
                {
                    _ud2.Ano = true;
                }
                dt.SubmitChanges();
            }

        }
    }

    private void CalculateActualEvent()
    {
        _status.ST.CashFlow = _status.ST.CashFlow + GetPrice(_NahodnaUdalost);
    }

    public void CalculatePeriodicEvent(FinCache.Udalost ud)
    {
        decimal cena = GetPricePeriodic(ud);
        String comment = "";
        if (cena >= 0)
        {
            comment = "Prijem z udalosti - ";
        }
        else
        {
            comment = "Výdaj z udalosti - ";
        }
        _status.ST.CashFlow = _status.ST.CashFlow + cena;
        Tools.AddFinancialNotification(_session, _status.ST.CurrentPeriod, ud.Nazov, comment + ud.Nazov + "  ", ud.Nazov, cena, false);


        _status.saveHistory();
        _status.SaveUserStatus();
    }

    private void CalculateAtualProperies()
    {
        //_status.ST.CashFlow = _status.ST.CashFlow + GetPrice(_NahodnaUdalost);
        if ((_NahodnaUdalost.TypMajetkuPrijem ?? "") == "Majetok")
        {
            _status.ST.MajetokHotovost = _status.ST.MajetokHotovost + _NahodnaUdalost.MAJETOKPrijem;
        }
        if ((_NahodnaUdalost.TypMajetkuVydaj ?? "") == "Majetok")
        {
            _status.ST.MajetokHotovost = _status.ST.MajetokHotovost - _NahodnaUdalost.MAJETOKPrijem;
        }

    }

    private decimal GetPrice(FinCache.Udalost ud)
    {
        decimal ret = 0;

        //----------MinusCashflow   PlusCashflow
        if (ud.TypCFVydaj == "MinusCashflow")
        {
            ret = ret - ud.CASHFLOWVydaj ?? 0;
        }
        if (ud.TypCFPrijem == "PlusCashflow")
        {
            ret = ret + ud.CASHFlowPrijem ?? 0;
        }
        //----------NasobokMesacnyPrijem
        if (ud.TypCFVydaj == "NasobokMesacnyPrijem")
        {
            ret = ret - ((ud.CASHFLOWVydaj ?? 0) * _status.ST.Prijem);
        }
        if (ud.TypCFPrijem == "NasobokMesacnyPrijem")
        {
            ret = ret + ((ud.CASHFlowPrijem ?? 0) * _status.ST.Prijem);
        }
        //----------NasobokMesacnyPrijem
        if (ud.TypCFVydaj == "NasobokRocnyPrijem")
        {
            ret = ret - ((ud.CASHFLOWVydaj ?? 0) * (_status.ST.Prijem * 12));
        }
        if (ud.TypCFPrijem == "NasobokRocnyPrijem")
        {
            ret = ret + ((ud.CASHFlowPrijem ?? 0) * (_status.ST.Prijem * 12));
        }
        //----------NasobokMesacnyCashFlow
        if (ud.TypCFVydaj == "NasobokMesacnyCashFlow")
        {
            ret = ret - ((ud.CASHFLOWVydaj ?? 0) * ((_status.ST.Prijem) - (_status.ST.Vydaje ?? 0) - (_status.ST.Najomne ?? 0)));
        }
        if (ud.TypCFPrijem == "NasobokMesacnyCashFlow")
        {
            ret = ret + ((ud.CASHFlowPrijem ?? 0) * ((_status.ST.Prijem) - (_status.ST.Vydaje ?? 0) - (_status.ST.Najomne ?? 0)));
        }
        //----------ROCNY PRIJEM VYDAJ
        if (ud.TypCFVydaj == "RocnyVydajPercenta")
        {
            ret = ret - (((ud.CASHFLOWVydaj ?? 0) * (_status.ST.Prijem)) * _fch.GetCiselnikValue("PeriodaRokov").IntValue ?? 3);
        }
        if (ud.TypCFPrijem == "RocnyPrijemPercenta")
        {
            ret = ret + (((ud.CASHFLOWVydaj ?? 0) * (_status.ST.Prijem)) * _fch.GetCiselnikValue("PeriodaRokov").IntValue ?? 3);
        }

        return ret;
    }

    private decimal GetPricePeriodic(FinCache.Udalost ud)
    {
        decimal ret = 0;
        int pocetRokovPerioda = _fch.GetCiselnikValue("PeriodaRokov").IntValue ?? 3;
        //----------MinusCashflow   PlusCashflow
        if (ud.TypCFVydaj == "MinusCashflow" & (ud.výdaj_každé_kolo ?? 0) == 1)
        {
            ret = ret - ((ud.CASHFLOWVydaj ?? 0) * pocetRokovPerioda);
        }
        if (ud.TypCFPrijem == "PlusCashflow" & (ud.príjem_každé_kolo ?? 0) == 1)
        {
            ret = ret + ((ud.CASHFlowPrijem ?? 0) * pocetRokovPerioda);
        }
        //----------NasobokMesacnyPrijem
        if (ud.TypCFVydaj == "NasobokMesacnyPrijem" & (ud.výdaj_každé_kolo ?? 0) == 1)
        {
            ret = ret - (((ud.CASHFLOWVydaj ?? 0) * _status.ST.Prijem) * pocetRokovPerioda);
        }
        if (ud.TypCFPrijem == "NasobokMesacnyPrijem" & (ud.príjem_každé_kolo ?? 0) == 1)
        {
            ret = ret + (((ud.CASHFlowPrijem ?? 0) * _status.ST.Prijem) * pocetRokovPerioda);
        }
        //----------NasobokMesacnyPrijem
        if (ud.TypCFVydaj == "NasobokRocnyPrijem" & (ud.výdaj_každé_kolo ?? 0) == 1)
        {
            ret = ret - (((ud.CASHFLOWVydaj ?? 0) * (_status.ST.Prijem * 12)) * pocetRokovPerioda);
        }
        if (ud.TypCFPrijem == "NasobokRocnyPrijem" & (ud.príjem_každé_kolo ?? 0) == 1)
        {
            ret = ret + (((ud.CASHFlowPrijem ?? 0) * (_status.ST.Prijem * 12)) * pocetRokovPerioda);
        }
        //----------NasobokMesacnyCashFlow
        if (ud.TypCFVydaj == "NasobokMesacnyCashFlow" & (ud.výdaj_každé_kolo ?? 0) == 1)
        {
            ret = ret - (((ud.CASHFLOWVydaj ?? 0) * ((_status.ST.Prijem) - (_status.ST.Vydaje ?? 0) - (_status.ST.Najomne ?? 0))) * pocetRokovPerioda);
        }
        if (ud.TypCFPrijem == "NasobokMesacnyCashFlow" & (ud.príjem_každé_kolo ?? 0) == 1)
        {
            ret = ret + (((ud.CASHFlowPrijem ?? 0) * ((_status.ST.Prijem) - (_status.ST.Vydaje ?? 0) - (_status.ST.Najomne ?? 0))) * pocetRokovPerioda);
        }
        //----------ROCNY PRIJEM VYDAJ
        if (ud.TypCFVydaj == "RocnyVydajPercenta" & (ud.výdaj_každé_kolo ?? 0) == 1)
        {
            ret = ret - (((ud.CASHFLOWVydaj ?? 0) * (_status.ST.Prijem)) * pocetRokovPerioda);
        }
        if (ud.TypCFPrijem == "RocnyPrijemPercenta" & (ud.príjem_každé_kolo ?? 0) == 1)
        {
            ret = ret + (((ud.CASHFLOWVydaj ?? 0) * (_status.ST.Prijem)) * pocetRokovPerioda);
        }

        return ret;
    }

    private void PickRandomUdalost()
    {
        Random random = new Random();
        bool start = true;
        List<UdalostToPick> pickList = new List<UdalostToPick>();
        int end = 0;
        List<StavHracaUdalosti> RemoveUsedItem = null;
        List<Majetok> RemoveByMajetok = null;

        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            RemoveUsedItem = dt.GetUserUdalosti(_session).ToList();
            RemoveByMajetok = dt.GetUserMajetok(_session).Where(m => m.AffectedFinId != "0").ToList();

        }
        if (RemoveUsedItem != null)
        {
            foreach (var item in RemoveUsedItem)
            {
                if (item.EliminatesItSelf == true)
                {
                    _Udalosti.RemoveAll(i => i.id == (item.idUdalosti ?? 0));
                }
            }
        }
        if (RemoveByMajetok != null)
        {
            foreach (var item in RemoveByMajetok)
            {
                _Udalosti.RemoveAll(i => i.id.ToString() == item.AffectedFinId);
            }
        }
        //_Udalosti.RemoveAll(i => i.kod == "Nehnutelnost");
        //_Udalosti.RemoveAll(i => i.AktivneDoVeku >= _status.ST.Vek);

        foreach (var item in _Udalosti)
        {
            UdalostToPick pck = new UdalostToPick();

            if (start)
            {
                pck.id = item.id;
                pck.Start = 0;
                pck.End = pck.Start + (Convert.ToInt32(item.Pravdepodobnost) * 1000) - 1;
                end = pck.End;
                start = false;
            }
            else
            {
                pck.id = item.id;
                pck.Start = end;
                pck.End = pck.Start + (Convert.ToInt32(item.Pravdepodobnost) * 1000) - 1;
                end = pck.End;
            }

            pickList.Add(pck);
        }
        int nahoda = random.Next(1, end);
        int retId = 0;

        foreach (var item in pickList)
        {
            if ((nahoda > item.Start) & (nahoda <= item.End))
            {
                retId = item.id;
            }

        }


        _NahodnaUdalost = (from a in _Udalosti
                           where a.id == retId
                           select a).FirstOrDefault();

        var insurance = RemoveByMajetok.Where(m => m.AffectedFinId == _NahodnaUdalost.kod);
        if (insurance.Count() > 0)
        {
            insured = true;
        }
        else
        {
            insured = false;
        }
    }

    private struct UdalostToPick
    {
        public int id;
        public int Start;
        public int End;
    }

}