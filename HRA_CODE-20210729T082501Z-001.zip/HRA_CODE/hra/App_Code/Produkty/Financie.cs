﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Financie
/// </summary>
public class FinFinancie
{
    private FinCache.FinCache _fch = null;
    private UserStatus _status = null;
    private int _Period;
    private string _SessionId;
    public FinFinancie(int Period, string SessionId)
	{
        _Period = Period;
        _SessionId = SessionId;
        _fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(_SessionId);
	}
    public void PrepocitajPrijmyRodiny()
    {
        decimal zaklad = ((_status.ST.PrijemMuz + _status.ST.PrijemZena - _status.ST.Najomne - _status.ST.Vydaje) * 12 * _fch.GetCiselnikValue("PeriodaRokov").IntValue ?? 3);
        _status.UpdateFreeCashflow(zaklad ,false);
    }
}