﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for FinUvery
/// </summary>
public class FinUvery
{
    private List<FinCache.Akcia> _akcie = null;
    private FinCache.FinCache _fch = null;
    private int _Period;
    private string _SessionId;
    private UserStatus _status = null;
    public FinUvery(int Period, string SessionId)
    {
        _Period = Period;
        _SessionId = SessionId;
        _fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(_SessionId);
    }

    public void BuyLoan(String LoanType, decimal VyskaUveru, int PocetSplatok, decimal SplatkaZaObdobie, String LoanTypeName)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            Majetok m = new Majetok();
            m.Active = true;
            m.Sold = false;
            m.SessionID = _SessionId;
            m.CurrentPeriod = _Period;
            m.DatumZapisu = DateTime.Now;
            m.AffectedFinId = _fch.FinDlhopisAll.FirstOrDefault().ElimKodUdalosti;
            m.AffectedUdalostID = 0;
            m.Type = LoanType;
            m.Name = LoanTypeName;
            m.PriceBuy = VyskaUveru;
            m.PriceSell = 0;
            m.NumberPeriodRepay = PocetSplatok;
            m.PeriodCFChange = -1 * SplatkaZaObdobie;
            m.PeriodDuration = PocetSplatok;
            dt.Majetoks.InsertOnSubmit(m);
            dt.SubmitChanges();
        }
        _status.UpdateFreeCashflow(VyskaUveru, false);
    }

    public String GetNumberOFMajetok()
    {
        string ret = "0";
        int i = 0;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            i = (dt.GetUserMajetokByProductName(_SessionId, "Uver")).Count();
            i = i + (dt.GetUserMajetokByProductName(_SessionId, "Hypoteka")).Count();
            ret = i.ToString();
        }
        return ret;
    }
    public String GetNumberOFMajetok(String Code)
    {
        string ret = "0";
        int i = 0;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            i = (dt.GetUserMajetokByProductLike(_SessionId, Code, "Uver")).Count();
            i = i + (dt.GetUserMajetokByProductLike(_SessionId, Code, "Hypoteka")).Count();
            ret = i.ToString();
        }
        return ret;
    }
    public int GetSumOFMajetok(String Type)
    {
        int ret = 0;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            ret = (dt.GetUserMajetokByProductName(_SessionId, Type)).Count();
        }
        return ret;
    }
}