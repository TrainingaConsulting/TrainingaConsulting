﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for StavebneProrenia
/// </summary>
public class FinStavebneSporenia
{
    private List<FinCache.SS> _akcie = null;
    private FinCache.FinCache _fch = null;
    private int _Period;
    private string _SessionId;
    private List<StavHracaProdukty> _stavyProduktov = null;
    private UserStatus _status = null;
    public FinStavebneSporenia(int Period, string SessionId)
    {
        _Period = Period;
        _SessionId = SessionId;
        _fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(_SessionId);

    }
    public FinStavebneSporenia(string SessionId)
    {
       
        _SessionId = SessionId;
        _fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(_SessionId);
        _Period = _status.ST.CurrentPeriod;
    }

    public bool CanBuyBuildLoan(string SessionId, string ProductCode)
    {
        bool ret = true;
        //if (ProductCode == "SS4")
        //{
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                int majetokCNT = dt.GetUserMajetokByProduct(SessionId, ProductCode).Count();
                if (majetokCNT > 0 ) //_status.ST.PocetDeti + 2
                {
                    ret = false;
                }
            }
        //}
        return ret;
    }

    public void BuyBuildLoan(string SessionId, string ProductCode)
    {
        var loan = (from a in _fch.FinSsAll where a.Kod == ProductCode select a).FirstOrDefault();
        Majetok m = null;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            m = new Majetok();
            m.Active = true;
            m.Sold = false;
            m.SessionID = _SessionId;
            m.CurrentPeriod = _Period;
            m.DatumZapisu = DateTime.Now;
            m.AffectedFinId = _fch.FinDlhopisAll.FirstOrDefault().ElimKodUdalosti;
            m.AffectedUdalostID = 0;
            m.Type = ProductCode;
            m.Name = "StavebneSporenie";
            m.PriceBuy = loan.VyskaUveru ;
            m.YearCFChange = 0;
            m.PeriodCFChange = -1 * loan.VkladObdobie;
            m.PriceSell = 0;
            m.PeriodDuration = loan.PocetVkladov ?? 0;
            dt.Majetoks.InsertOnSubmit(m);
            dt.SubmitChanges();
        }
        _status.UpdateFreeCashflow(m.PriceBuy ?? 0, false);
    }

    public String GetNumberOFMajetok()
    {
        int ret = 0;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            ret = (dt.GetUserMajetokByProductName(_SessionId, "StavebneSporenie")).Count();

        }
        return ret.ToString();
    }
}