﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for FinPoistenia
/// </summary>
public class FinPoistenia
{
    private FinCache.FinCache _fch = null;
    private int _Period;
    private string _SessionId;
    private List<FinCache.DistinctPoistenia> _productList = null;
    private List<StavHracaProdukty> _stavyProduktov = null;
    private List<Majetok> _majetok = null;
    private UserStatus _status = null;
    public FinPoistenia(int Period, string SessionId)
    {
        _Period = Period;
        _SessionId = SessionId;
        _fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(_SessionId);
        _productList = _fch.FinPoisteniaDist;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            _majetok = dt.GetUserMajetokByProductName(_SessionId, "Poistenie").ToList();
        }
    }

    public void AddStavHracaProdukty(int Period)
    {
        Random random = new Random();
        StavHracaProdukty st = null;
        _Period = Period;
        foreach (var item in _productList)
        {
            if (isRandomEarnProduct(item.Kod))
            {
                if (_Period == 0)
                {
                    st = GetFirstStatus(item.Kod);
                }
                else
                {
                    using (DataClassesDataContext dt = new DataClassesDataContext())
                    {
                        var poistky = _fch.FinDlhopisAll.Select(m => m).Where(mo => mo.Kod == item.Kod);
                        st = new StavHracaProdukty();
                        st.KodProduktu = item.Kod;
                        st.rand1 = random.Next(poistky.Min(t => t.Rand) ?? 0, poistky.Max(t => t.Rand) ?? 10);
                        st.rand2 = 0;
                        st.SessionId = _SessionId;
                        st.Perioda = _Period;
                        st.urok1 = (_fch.FinDlhopisAll.Select(m => m).Where(mo => mo.Rand == st.rand1).FirstOrDefault()).ZiskPerioda;
                        st.urok2 = 0;
                        st.DatumZapisu = DateTime.Now;
                        st.HodnotaProduktu = 0;// CenaDlhopisu(Convert.ToDecimal(st.urok1));
                        st.HodnotaVynosu = VynosPoistenia(Convert.ToDecimal(st.urok1), item.Kod);
                        dt.StavHracaProdukties.InsertOnSubmit(st);
                        dt.SubmitChanges();
                    }
                }
            }
        }

    }
    public StavHracaProdukty GetActualStatus(String ProductCode)
    {
        StavHracaProdukty stat = null;
        if (_Period == 0)
        {
            stat = GetFirstStatus(ProductCode);
        }
        else
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                _stavyProduktov = dt.GetUserProductsStatus(_SessionId, ProductCode).ToList<StavHracaProdukty>();
            }
            stat = (from a in _stavyProduktov
                    where a.Perioda == _Period
                    select a).FirstOrDefault();
        }
        return stat;
    }
    public StavHracaProdukty GetPreviousStatus(string ProductCode)
    {
        StavHracaProdukty stat = null;
        if (_Period == 0)
        {
            stat = GetFirstStatus(ProductCode);
        }
        else
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                _stavyProduktov = dt.GetUserProductsStatus(_SessionId, ProductCode).ToList<StavHracaProdukty>();
            }
            stat = (from a in _stavyProduktov
                    where a.Perioda == (_Period - 1)
                    select a).FirstOrDefault();
        }


        return stat;
    }

    //public decimal CenaPoistenia()
    //{
    //    if (_Period == 0)
    //    {
    //        return GetFirstStatus().HodnotaProduktu;
    //    }
    //    else
    //    {
    //        return GetPreviousStatus().HodnotaProduktu + (GetPreviousStatus().HodnotaProduktu * Convert.ToDecimal(GetActualStatus().urok1));
    //    }
    //}
    //public decimal CenaPoistenia(decimal urok)
    //{
    //    if (_Period == 0)
    //    {
    //        return GetFirstStatus().HodnotaProduktu;
    //    }
    //    else
    //    {
    //        return GetPreviousStatus().HodnotaProduktu + (GetPreviousStatus().HodnotaProduktu * urok);
    //    }
    //}

    public decimal VynosPoistenia(String ProductCode)
    {
        if (_Period == 0)
        {
            return 0;
        }
        else
        {
            return GetPreviousStatus(ProductCode).HodnotaProduktu * Convert.ToDecimal(GetActualStatus(ProductCode).urok1);
        }
    }
    public decimal VynosPoistenia(decimal urok, String ProductCode)
    {
        if (_Period == 0)
        {
            return 0;
        }
        else
        {
            return GetPreviousStatus(ProductCode).HodnotaProduktu * urok;
        }
    }

    private StavHracaProdukty GetFirstStatus(String ProductCode)
    {
        StavHracaProdukty st = new StavHracaProdukty();
        st.KodProduktu = ProductCode;
        st.rand1 = 0;
        st.rand2 = 0;
        st.SessionId = _SessionId;
        st.Perioda = 0;
        st.urok1 = 0;
        st.urok2 = 0;
        st.HodnotaProduktu = _fch.FinDlhopisAll.FirstOrDefault().JednotkovaCena ?? 0;
        st.DatumZapisu = DateTime.Now;
        return st;
    }

    private bool isRandomEarnProduct(string ProductCode)
    {
        bool ret = false;
        var temp = _fch.FinPoisteniaAll.Select(m => m).Where(mo => mo.Kod == ProductCode).ToList();

        if (temp.Count > 1)
        {
            if (temp[1].Rand > 0)
            {
                ret = true;
            }
        }
        return ret;
    }

    public String GetNumberOFMajetok()
    {
        string ret = "0";
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            var c1 = (dt.GetUserMajetokByProductName(_SessionId, "Urazove")).Count();
            var c2 = (dt.GetUserMajetokByProductName(_SessionId, "Zivotne")).Count();

            ret = (c1 + c2).ToString();
        }
        return ret;
    }
    public String GetNumberOFMajetok(String type)
    {
        string ret = "0";
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            ret = (dt.GetUserMajetokByProductName(_SessionId, type)).Count().ToString(); ;

        }
        return ret;
    }


    public bool BuyInsurance(String InsuranceType)
    {
        FinCache.Poistenia itt = new FinCache.Poistenia();
        itt = _fch.FinPoisteniaAll.Select(ma => ma).Where(mo => mo.Kod == InsuranceType).FirstOrDefault();
        Majetok mm = null;
        Boolean ret = false;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            mm = dt.GetUserMajetokByProductName(_SessionId, itt.Typ).FirstOrDefault();
        }
        if (mm == null)
        {
            if (itt.Rand > 0)
            {
                BuyIns(InsuranceType, itt, 0, itt.ZiskPerioda ?? 1);
                ret = true;
            }
            if (itt.Rand == 0)
            {
                if (itt.ZiskPerioda > 0)
                {
                    BuyIns(InsuranceType, itt, itt.ZiskPerioda ?? 1, 0);
                    ret = true;
                }
                if (itt.ZiskPerioda == 0)
                {
                    BuyIns(InsuranceType, itt, 0, 0);
                    ret = true;

                }
            }
        }
        return ret;
    }

    public bool CancelInsurance(string InsuranceType)
    {
        FinCache.Poistenia itt = new FinCache.Poistenia();
        itt = _fch.FinPoisteniaAll.Select(ma => ma).Where(mo => mo.Kod == InsuranceType).FirstOrDefault();
        Boolean ret = false;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            var a = dt.GetUserMajetokByProductName(_SessionId, itt.Typ).FirstOrDefault();
            //a.PriceSell = CenaDlhopisu();
            if (a != null)
            {
                a.Sold = true;
                dt.SubmitChanges();
                ret = true;
            }

            //_status.UpdateFreeCashflow(a.PriceBuy ?? 0, false);
        }
        return ret;
    }

    private void BuyIns(String InsuranceType, FinCache.Poistenia itt, decimal staticPerc, Decimal DynamicPer)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            Majetok m = new Majetok();
            m.Active = true;
            m.Sold = false;
            m.SessionID = _SessionId;
            m.CurrentPeriod = _Period;
            m.DatumZapisu = DateTime.Now;
            m.AffectedFinId = itt.ElimKodUdalosti;
            m.AffectedUdalostID = 0;
            m.Type = InsuranceType;
            m.Name = itt.Typ;
            m.PriceBuy = 0;
            m.PriceSell = itt.CielovaSumaPoistenia ?? 0;
            m.StaticPercentage = staticPerc;
            m.DynamicPercentage = DynamicPer;
            m.NumberPeriodRepay = 1000;
            m.PeriodCFChange = -1 * ((itt.VkladRok ?? 0) * (_fch.GetCiselnikValue("PeriodaRokov").IntValue ?? 3));
            m.PeriodDuration = 1000;
            dt.Majetoks.InsertOnSubmit(m);
            dt.SubmitChanges();
        }
    }
}