﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Dlhopisy
/// </summary>
public class FinDlhopisy
{
    private FinCache.FinCache _fch = null;
    private int _Period;
    private string _SessionId;
    private List<StavHracaProdukty> _stavyProduktov = null;
    private UserStatus _status = null;

    public FinDlhopisy(int Period, string SessionId)
    {
        _Period = Period;
        _SessionId = SessionId;
        _fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(_SessionId);
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            _stavyProduktov = dt.GetUserProductsStatus(_SessionId, "DPS").ToList<StavHracaProdukty>();
        }
    }

    public void AddStavHracaProdukty(int Period)
    {
        Random random = new Random();
        StavHracaProdukty st = null;
        _Period = Period;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            if (_Period == 0)
            {
                st = GetFirstStatus();
            }
            else
            {
                st = new StavHracaProdukty();
                st.KodProduktu = "DPS";
                st.rand1 = random.Next(_fch.FinDlhopisAll.Min(t => t.Rand) ?? 0, _fch.FinDlhopisAll.Max(t => t.Rand) ?? 10);
                st.rand2 = 0;
                st.SessionId = _SessionId;
                st.Perioda = _Period;
                st.urok1 = (_fch.FinDlhopisAll.Select(m => m).Where(mo => mo.Rand == st.rand1).FirstOrDefault()).ZiskPerioda;
                st.urok2 = 0;
                st.DatumZapisu = DateTime.Now;
                st.HodnotaProduktu = CenaDlhopisu(Convert.ToDecimal(st.urok1));
                st.HodnotaVynosu = VynosDlhopisu(Convert.ToDecimal(st.urok1));
            }
            dt.StavHracaProdukties.InsertOnSubmit(st);
            dt.SubmitChanges();
        }
    }
    public StavHracaProdukty GetActualStatus()
    {
        StavHracaProdukty stat = null;
        if (_Period == 0)
        {
            stat = GetFirstStatus();
        }
        else
        {
            stat = (from a in _stavyProduktov
                    where a.Perioda == _Period
                    select a).FirstOrDefault();
        }
        return stat;
    }
    public StavHracaProdukty GetPreviousStatus()
    {
        StavHracaProdukty stat = null;
        if (_Period == 0)
        {
            stat = GetFirstStatus();
        }
        else
        {
            stat = (from a in _stavyProduktov
                    where a.Perioda == (_Period - 1)
                    select a).FirstOrDefault();
        }


        return stat;
    }

    public decimal CenaDlhopisu()
    {
        if (_Period == 0)
        {
            return GetFirstStatus().HodnotaProduktu;
        }
        else
        {
            return GetPreviousStatus().HodnotaProduktu + (GetPreviousStatus().HodnotaProduktu * Convert.ToDecimal(GetActualStatus().urok1));
        }
    }
    public decimal CenaDlhopisu(decimal urok)
    {
        if (_Period == 0)
        {
            return GetFirstStatus().HodnotaProduktu;
        }
        else
        {
            return GetPreviousStatus().HodnotaProduktu + (GetPreviousStatus().HodnotaProduktu * urok);
        }
    }

    public decimal VynosDlhopisu()
    {
        if (_Period == 0)
        {
            return 0;
        }
        else
        {
            return GetPreviousStatus().HodnotaProduktu * Convert.ToDecimal(GetActualStatus().urok1);
        }
    }
    public decimal VynosDlhopisu(decimal urok)
    {
        if (_Period == 0)
        {
            return 0;
        }
        else
        {
            return GetPreviousStatus().HodnotaProduktu * urok;
        }
    }

    private StavHracaProdukty GetFirstStatus()
    {
        StavHracaProdukty st = new StavHracaProdukty();
        st.KodProduktu = "DPS";
        st.rand1 = 0;
        st.rand2 = 0;
        st.SessionId = _SessionId;
        st.Perioda = 0;
        st.urok1 = 0;
        st.urok2 = 0;
        st.HodnotaProduktu = _fch.FinDlhopisAll.FirstOrDefault().JednotkovaCena ?? 0;
        st.DatumZapisu = DateTime.Now;
        return st;
    }

    public void BuyDlhopis(int amount)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            Majetok m = new Majetok();
            m.Active = true;
            m.Sold = false;
            m.SessionID = _SessionId;
            m.CurrentPeriod = _Period;
            m.DatumZapisu = DateTime.Now;
            m.AffectedFinId = _fch.FinDlhopisAll.FirstOrDefault().ElimKodUdalosti;
            m.AffectedUdalostID = 0;
            m.ComputedPeriodPrice = true;
            m.Type = "DPS";
            m.Name = "Dlhopis";
            m.PriceBuy = GetActualStatus().HodnotaProduktu;
            m.PriceSell = 0;
            dt.Majetoks.InsertOnSubmit(m);
            dt.SubmitChanges();
        }
        _status.UpdateFreeCashflow(GetActualStatus().HodnotaProduktu, true);
    }
    public bool SellDlhopis(int amount)
    {
        bool ret = false;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            var a = dt.GetUserMajetokByProduct(_SessionId, "DPS").FirstOrDefault();
            if (a != null)
            {
                ret = true;
                a.PriceSell = CenaDlhopisu();
                a.Sold = true;
                dt.SubmitChanges();
            }
        }
        if (ret)
        {
          _status.UpdateFreeCashflow(GetActualStatus().HodnotaProduktu, false);  
        }
        return ret;
    }
    public String GetNumberOFMajetok()
    {
        string ret = "0";
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            ret = (dt.GetUserMajetokByProduct(_SessionId, "DPS")).Count().ToString();
        }
        return ret;
    }
    public Int32 getNumOfPossibleMajetok()
    {
        return Convert.ToInt32(_status.ST.CashFlow ?? 1) / Convert.ToInt32(CenaDlhopisu());
    }
    public List<MajetokInfo> GetMajetokInfo()
    {
        MajetokInfo retItem = new MajetokInfo();
        List<MajetokInfo> ret = new List<MajetokInfo>();
        retItem.Pocet = 0;
        retItem.Cena = "0";
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {

            retItem.Pocet = dt.GetUserMajetokByProduct(_SessionId, "DPS").Count();
            retItem.CenaDec = CenaDlhopisu() * retItem.Pocet;
            retItem.Cena = (retItem.CenaDec).ToString("# ##0");
        }
        ret.Add(retItem);
        return ret;
    }
    public class MajetokInfo
    {
        public int Pocet;
        public String Cena;
        public decimal CenaDec;
    }
}

