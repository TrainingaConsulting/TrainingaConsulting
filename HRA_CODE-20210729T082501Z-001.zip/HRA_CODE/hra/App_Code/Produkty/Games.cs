﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Games
/// </summary>
public class FinGame
{
    private FinCache.FinCache _fch = null;
    private Udalosti _UdalostiObj = null;
    List<FinCache.Udalost> _Udal = null;
    public UserStatus _user = null;
    public FinDlhopisy _dlhopisy = null;
    public FinPodiely _Podiely = null;
    public FinAkcie _Akcie = null;
    public FinFinancie _financie = null;
    public FinGame(String SessionId, int period)
    {
        _fch = FinCache.FinCache.GetInstance();
        _Udal = _fch.FinUdalost;

        _financie = new FinFinancie(period, SessionId);
        _dlhopisy = new FinDlhopisy(period, SessionId);
        _Podiely = new FinPodiely(period, SessionId);
        _Akcie = new FinAkcie(period, SessionId);
    }

    public FinGame(String SessionId)
    {
        _fch = FinCache.FinCache.GetInstance();
        _Udal = _fch.FinUdalost;

        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            _user = new UserStatus(SessionId);
        }
        _dlhopisy = new FinDlhopisy(_user.ST.CurrentPeriod, SessionId);
        _Podiely = new FinPodiely(_user.ST.CurrentPeriod, SessionId);
        _Akcie = new FinAkcie(_user.ST.CurrentPeriod, SessionId);
        _financie = new FinFinancie(_user.ST.CurrentPeriod, SessionId);
    }

    public void NextPeriod()
    {
        //(_fch.FinCiselnik.Select(m => m).Where(mo => mo.Name == "PeriodaRokov").FirstOrDefault()).IntValue ?? 3;
        _user.ST.Vek = _user.ST.Vek + _fch.GetCiselnikValue("PeriodaRokov").IntValue ?? 3;
        _user.ST.CurrentPeriod = _user.ST.CurrentPeriod + 1;
        ProcessPeriodicPayments();

        decimal PropertyTotal = _Akcie.GetMajetokInfo()[0].CenaDec + _dlhopisy.GetMajetokInfo()[0].CenaDec + _Podiely.GetMajetokInfo()[0].CenaDec;

        _user.SaveUserStatus();
        _user.saveHistory(PropertyTotal);
        _financie.PrepocitajPrijmyRodiny();

        
    }

    private void ProcessPeriodicPayments()
    {
        // Process inflation start
        decimal? inflTemp = _fch.GetCiselnikValue("Inflacia").DecValue;
        decimal inflacia = 0;
        if ((inflTemp ?? 0) != 0)
        {
            for (int i = 0; i < (_fch.GetCiselnikValue("PeriodaRokov").IntValue ?? 3); i++)
            {
                _user.ST.Prijem = _user.ST.Prijem + (inflTemp ?? 1) * _user.ST.Prijem;
                inflacia = inflacia + (inflTemp ?? 1) * _user.ST.Prijem;
            }
            Tools.AddFinancialNotification(_user.ST.SessionID, _user.ST.CurrentPeriod, "Vplyv inflacie na prijem :", "Vplyv inflacie na prijem :", "infl", inflacia, false);
        }
        //Process inflation end
        


    }
    public void AddStatuses()
    {
        _dlhopisy.AddStavHracaProdukty(_user.ST.CurrentPeriod);
        _Podiely.AddStavHracaProdukty(_user.ST.CurrentPeriod);
        _Akcie.AddStavHracaProdukty(_user.ST.CurrentPeriod);
    }
    public void AddStatuses(int Period)
    {
        _dlhopisy.AddStavHracaProdukty(Period);
        _Podiely.AddStavHracaProdukty(Period);
        _Akcie.AddStavHracaProdukty(Period);

    }


}