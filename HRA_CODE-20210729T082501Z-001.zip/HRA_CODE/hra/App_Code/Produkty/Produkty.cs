﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Produkty
/// </summary>
public class Produkty
{
    public FinDlhopisy Dlhopisy = null;
    public FinAkcie Akcie = null;
    public FinPodiely FinPodiely = null;
    private int _Period;
    private string _SessionId;
    public Produkty(int Period, string SessionId)
    {
        _Period = Period;
        _SessionId = SessionId;
        Dlhopisy = new FinDlhopisy(_Period, _SessionId);

        Akcie = new FinAkcie(_Period, _SessionId);


    }
}