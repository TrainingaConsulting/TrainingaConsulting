﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for GraphMaker
/// </summary>
public class GraphMaker
{
    private System.Web.UI.Page _page;
    private string _sourcePath;
    private string _destPath;
    private string _sourceFileName;
    private string _destinationFileName;
    private string _SessionID;
    Bitmap TmpBitmap;

    #region graphics settings
    private Color Shade1;
    private Pen Shade1Pen;
    private Color Shade2;
    private Pen Shade2Pen;
    private Color Shade3;
    private Pen Shade3Pen;
    private Color Shade4;
    private Pen Shade4Pen;
    private Color Shade5;
    private Pen Shade5Pen;


    private Color redColor;
    private Pen redPen;

    private Color blueColor;
    private Pen bluePen;


    #endregion


    public GraphMaker(System.Web.UI.Page page)
    {
        _page = page;
        _SessionID = _page.Session.SessionID;
        _sourcePath = _page.Server.MapPath("~/App_Themes/Images/Middle/");
        _destPath = _page.Server.MapPath("~/Graphs/");
        _sourceFileName = "Graf.jpg";
        _destinationFileName = _SessionID + "_Graf.jpg";

        //_tmp = _page.Server.MapPath("~/Exports/tmp");

        SetColorsAndPens();


    }

    private void SetColorsAndPens()
    {
        Shade1 = Color.FromArgb(87, 87, 87);
        Shade1Pen = new Pen(Shade1, 1);
        Shade2 = Color.FromArgb(110, 110, 110);
        Shade2Pen = new Pen(Shade2, 1);
        Shade3 = Color.FromArgb(140, 140, 140);
        Shade3Pen = new Pen(Shade3, 1);
        Shade4 = Color.FromArgb(179, 179, 179);
        Shade4Pen = new Pen(Shade4, 1);
        Shade5 = Color.FromArgb(209, 209, 209);
        Shade5Pen = new Pen(Shade5, 1);

        redColor = Color.FromArgb(227, 0, 27);
        redPen = new Pen(redColor, 35);

        blueColor = Color.FromArgb(32, 65, 122);
        bluePen = new Pen(blueColor, 4);
    }

    public GraphMaker(string SessionID)
    {
        _SessionID = SessionID;
        _sourcePath = _page.Server.MapPath("~/App_Themes/Images/Middle/");
        _destPath = _page.Server.MapPath("~/Graphs/");
        _sourceFileName = "grap.jpg";
        _destinationFileName = _SessionID + "_graph.jpg";

    }
    public bool preparegraph (List<GraphMaker.GraphData> data)
    {
        bool ret = false;

        TmpBitmap = new Bitmap(_sourcePath + _sourceFileName);
        Graphics TmpGraphics = Graphics.FromImage(TmpBitmap);

        TmpGraphics.DrawString("Grafické zobrazenie priebehu hry", new Font("Arial", 21.0f, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Black), 200, 30);

        TmpGraphics.DrawString("Vek", new Font("Arial", 14.0f, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Black), 880, 470);



        Decimal maxnumber = getMaxNumber(data);

        WriteEuros(TmpGraphics, decimal.ToInt32(maxnumber));

        List<GraphMaker.GraphData> mydata = PrepareData(data, maxnumber);

        foreach (var item in mydata)
        {
            DrawBar(TmpGraphics, item.Position, item.PercentualHeigh, item.Age, item.EventName);
            
        }

        DrawLine(TmpGraphics, PrepareMajetokData(mydata));
        
        //writegraph(TmpGraphics);
        
        ImageCodecInfo jpgEncoder = GetEncoder(ImageFormat.Jpeg);
        System.Drawing.Imaging.Encoder myEncoder = System.Drawing.Imaging.Encoder.Quality;
        System.Drawing.Imaging.EncoderParameters myEncoderParameters = new System.Drawing.Imaging.EncoderParameters(1);
        EncoderParameter myEncoderParameter = new EncoderParameter(myEncoder, 100L);
        myEncoderParameters.Param[0] = myEncoderParameter;
        TmpBitmap.Save(_destPath + _destinationFileName, jpgEncoder, myEncoderParameters);

        TmpBitmap.Dispose();

        return ret;
    }

    private decimal getMaxNumber(List<GraphMaker.GraphData> data)
    {
        decimal ret = 0;
        decimal ret2 = 0;

        ret = data.OrderByDescending(p => p.Value).FirstOrDefault().Value;
        ret2 = data.OrderByDescending(p => p.Majetok).FirstOrDefault().Majetok;

        if (ret2 > ret)
        {
            ret = ret2;
        }

        return ret;
    }

    private List<GraphMaker.GraphData> PrepareData(List<GraphMaker.GraphData> data, decimal maxValue)
    {
        List<GraphMaker.GraphData> ret = new List<GraphData>();
        decimal Percento = maxValue / 100;
        GraphData itm; 
        foreach (var item in data)
        {
            itm = item;
            itm.PercentualHeigh = decimal.ToInt32(item.Value / Percento);
            itm.MajetokPercentualHeigh = decimal.ToInt32(item.Majetok / Percento);
            itm.Position = itm.Position + 1;
            ret.Add(itm);
        }
        return ret.OrderBy(m => m.Position).ToList();
    }

    private List<int>PrepareMajetokData(List<GraphMaker.GraphData> data)
    {
        List<int> ret = new List<int>();
        int itt;
        foreach (var item in data)
        {
            itt = item.MajetokPercentualHeigh;
            ret.Add(itt);
        }
        return ret;
    }

    public struct GraphData
    {
        public int Position;
        public int Age;
        public int PercentualHeigh;
        public decimal Value;
        public decimal Majetok;
        public int MajetokPercentualHeigh;
        public string EventName;
    }


    private void writegraph(Graphics TmpGraphics)
    {

        for (int i = 1; i < 14; i++)
        {
            DrawBar(TmpGraphics, i, i * 5, i * 5, "Udalosť");
        }
        DrawBar(TmpGraphics, 15, 100, 100, "Tomáš");


        //List<int> majetok = new List<int>();

        //majetok.Add(15);
        //majetok.Add(60);
        //majetok.Add(30);
        //majetok.Add(20);
        //majetok.Add(21);
        //majetok.Add(60);
        //majetok.Add(15);
        //majetok.Add(80);
        //majetok.Add(90);
        //majetok.Add(100);
        //majetok.Add(18);
        //majetok.Add(22);
        //majetok.Add(90);
        //majetok.Add(95);

        //DrawLine(TmpGraphics, majetok);


    }

    private void DrawBar(Graphics TmpGraphics, int barNumber, decimal PercentualHeigh, int AgeValue, string EventName)
    {

        int distance = 50;
        distance = distance * barNumber;
        //100% = 356 points height calculation
        decimal heigh = (302m / 100) * PercentualHeigh;

        //start up parameters
        int xx1 = 100 + distance;
        int yy1 = 456 - decimal.ToInt32(heigh);
        int xx2 = 100 + distance;
        int yy2 = 456;
        //main graph
        TmpGraphics.DrawLine(redPen, xx1, yy1, xx2, yy2);

        writeText(TmpGraphics, EventName, yy1 - 20, xx1 - 10);

        // right shade
        int x1 = xx1 + (int)redPen.Width / 2 + 1;
        int y1 = yy1 + 4;
        int x2 = xx2 + (int)redPen.Width / 2 + 1;
        int y2 = yy2 + 1;
        TmpGraphics.DrawLine(Shade1Pen, x1, y1, x2, y2);

        x1 = xx1 + (int)redPen.Width / 2 + 2;
        y1 = yy1 + 4;
        x2 = xx2 + (int)redPen.Width / 2 + 2;
        y2 = yy2 + 2;
        TmpGraphics.DrawLine(Shade2Pen, x1, y1, x2, y2);

        x1 = xx1 + (int)redPen.Width / 2 + 3;
        y1 = yy1 + 4;
        x2 = xx2 + (int)redPen.Width / 2 + 3;
        y2 = yy2 + 2;
        TmpGraphics.DrawLine(Shade3Pen, x1, y1, x2, y2);

        x1 = xx1 + (int)redPen.Width / 2 + 4;
        y1 = yy1 + 4;
        x2 = xx2 + (int)redPen.Width / 2 + 4;
        y2 = yy2 + 2;
        TmpGraphics.DrawLine(Shade4Pen, x1, y1, x2, y2);

        x1 = xx1 + (int)redPen.Width / 2 + 5;
        y1 = yy1 + 4;
        x2 = xx2 + (int)redPen.Width / 2 + 5;
        y2 = yy2 + 2;
        TmpGraphics.DrawLine(Shade5Pen, x1, y1, x2, y2);

        //left shade
        x1 = xx1 - (int)redPen.Width / 2 + 1;
        y1 = yy2;
        x2 = xx2 + (int)redPen.Width / 2 + 1;
        y2 = yy2;
        TmpGraphics.DrawLine(Shade1Pen, x1, y1, x2, y2);

        x1 = xx1 - (int)redPen.Width / 2 + 2;
        y1 = yy2 + 1;
        x2 = xx2 + (int)redPen.Width / 2 + 2;
        y2 = yy2 + 1;
        TmpGraphics.DrawLine(Shade2Pen, x1, y1, x2, y2);

        x1 = xx1 - (int)redPen.Width / 2 + 3;
        y1 = yy2 + 2;
        x2 = xx2 + (int)redPen.Width / 2 + 3;
        y2 = yy2 + 2;
        TmpGraphics.DrawLine(Shade3Pen, x1, y1, x2, y2);

        int textDist = 6;
        if (AgeValue > 9 && AgeValue < 100)
        {
            textDist = 9;
        }
        if (AgeValue > 99)
        {
            textDist = 12;
        }

        TmpGraphics.DrawString(AgeValue.ToString(), new Font("Arial", 14, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Black), xx1 - textDist, yy2 + 15);

    }

    private void DrawLine(Graphics TmpGraphics, List<int> percentualHeight)
    {
        int distanceOne;
        int distanceNext;
        int distanceBase = 50;
        //100% = 356 points height calculation
        decimal heigh1; //= (302m / 100) * PercentualHeigh;
        decimal heigh2;
        int y1;
        int y2;
        //start up parameters
        //int xx1 = 100 + distance;
        //int yy1 = 456 - decimal.ToInt32(heigh);
        //int xx2 = 100 + distance;
        //int yy2 = 456;

        for (int i = 2; i < percentualHeight.Count; i++)
        {
            distanceOne = 100 + distanceBase * (i - 1);
            distanceNext = 100 + distanceBase * i;
            heigh1 = (302m / 100) * percentualHeight[i-1];
            heigh2 = (302m / 100) * percentualHeight[i];
            y1 = 456 - decimal.ToInt32(heigh1);
            y2 = 456 - decimal.ToInt32(heigh2);

            TmpGraphics.DrawLine(bluePen, distanceOne,y1, distanceNext,y2);

        }



    }

    private void writeText(Graphics TmpGraphics, string text, int PositionX, int PositionY)
    {

        GraphicsState state = TmpGraphics.Save();
        System.Drawing.Font drawFont = new System.Drawing.Font("Arial", 8, FontStyle.Bold);
        System.Drawing.SolidBrush drawBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Black);
        float x = PositionX;
        float y = PositionY;
        System.Drawing.StringFormat drawFormat = new System.Drawing.StringFormat();
        TmpGraphics.RotateTransform(-90);
        TmpGraphics.TranslateTransform(y, x, MatrixOrder.Append);
        TmpGraphics.DrawString(text, drawFont, drawBrush, 0, 0);
        TmpGraphics.Restore(state);

    }

    private void WriteEuros(Graphics TmpGraphics, int MaxValue)
    {
        int val1;
        int val2;
        int val3;
        int val4;

        val1 = decimal.ToInt32((MaxValue / 100m) * 20);
        val2 = decimal.ToInt32((MaxValue / 100m) * 40);
        val3 = decimal.ToInt32((MaxValue / 100m) * 60);
        val4 = decimal.ToInt32((MaxValue / 100m) * 80);

        CultureInfo ci = new CultureInfo("en-us");
        
        Rectangle rect = new Rectangle(5,147, 90, 16);
        StringFormat stringFormat = new StringFormat();
        stringFormat.Alignment = StringAlignment.Far;
        stringFormat.LineAlignment = StringAlignment.Far;

        TmpGraphics.DrawString(MaxValue.ToString("N0", ci), new Font("Arial", 14, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Black), rect, stringFormat);
        rect = new Rectangle(5, 212, 90, 16);
        TmpGraphics.DrawString(val4.ToString("N0", ci), new Font("Arial", 14, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Black), rect, stringFormat);
        rect = new Rectangle(5, 276, 90, 16);
        TmpGraphics.DrawString(val3.ToString("N0", ci), new Font("Arial", 14, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Black), rect, stringFormat);
        rect = new Rectangle(5, 332, 90, 16);
        TmpGraphics.DrawString(val2.ToString("N0", ci), new Font("Arial", 14, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Black), rect, stringFormat);
        rect = new Rectangle(5, 390, 90, 16);
        TmpGraphics.DrawString(val1.ToString("N0", ci), new Font("Arial", 14, System.Drawing.FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Black), rect, stringFormat);
    }


    private ImageCodecInfo GetEncoder(ImageFormat format)
    {
        ImageCodecInfo[] codecs = ImageCodecInfo.GetImageDecoders();
        foreach (ImageCodecInfo codec in codecs)
            if (codec.FormatID == format.Guid)
                return codec;
        return null;
    }
}