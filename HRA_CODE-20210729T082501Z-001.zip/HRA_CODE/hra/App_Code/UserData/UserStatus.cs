﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserStatus
/// </summary>
public class UserStatus
{
    public StavHraca ST = null;
    private StavHracaHistoria sth = null;
    public List<StavHracaProdukty> StavHracaProdukty = null;
    public List<Majetok> majetok = null;
    private string _sessionID = null;
    public UserStatus(string SessionId)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            ST = (StavHraca)dt.GetUserStatus(SessionId).FirstOrDefault();
            //StavHracaProdukty = dt.GetUserProductsStatus(SessionId).ToList();
            majetok = dt.GetUserMajetok(SessionId).ToList<Majetok>();
            _sessionID = SessionId;
        }
        sth = new StavHracaHistoria();
    }

    public StavHracaHistoria GetFirstStatus(string SessionId)
    {
        StavHracaHistoria ret = null;
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            ret = dt.GetUserStatusHistoria(SessionId).FirstOrDefault<StavHracaHistoria>();

            //var res = dt.GetUserStatusHistoria(SessionId);


            //ret = (from a in res
            //       orderby a.Id descending
            //       select a).FirstOrDefault();

        }
        return ret;
    }

    public bool saveHistory()
    {
        bool ret = false;
        sth = new StavHracaHistoria();
        FinDlhopisy _dlhopisy = new FinDlhopisy(ST.CurrentPeriod, _sessionID);
        FinPodiely _Podiely = new FinPodiely(ST.CurrentPeriod, _sessionID);
        FinAkcie _Akcie = new FinAkcie(ST.CurrentPeriod, _sessionID);
        decimal PropertyTotal = _Akcie.GetMajetokInfo()[0].CenaDec + _dlhopisy.GetMajetokInfo()[0].CenaDec + _Podiely.GetMajetokInfo()[0].CenaDec;
        try
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                sth.PrijemMuz = ST.PrijemMuz;
                sth.PrijemZena = ST.PrijemZena;
                sth.Prijem = ST.Prijem;
                sth.SessionID = ST.SessionID;
                sth.Vek = ST.Vek;
                sth.PocetDeti = ST.PocetDeti;
                sth.Vydaje = ST.Vydaje;
                sth.Najomne = ST.Najomne;
                sth.CurrentPeriod = ST.CurrentPeriod;
                sth.CashFlow = ST.CashFlow;
                sth.MajetokHotovost = ST.MajetokHotovost;
                sth.FondyPenaznehoTrhu = ST.FondyPenaznehoTrhu;
                sth.SpotrebitelskeUvery = ST.SpotrebitelskeUvery;
                sth.Ciel1 = ST.Ciel1;
                sth.Ciel2 = ST.Ciel2;
                sth.Ciel3 = ST.Ciel3;
                sth.Ciel1Id = ST.Ciel1Id;
                sth.Ciel2Id = ST.Ciel2Id;
                sth.Ciel3Id = ST.Ciel3Id;
                sth.SplnenyCiel1 = ST.SplnenyCiel1;
                sth.SplnenyCiel2 = ST.SplnenyCiel2;
                sth.SplnenyCiel3 = ST.SplnenyCiel3;
                sth.MajetokDynamicSpolu = PropertyTotal;
                sth.DatumZapisu = DateTime.Now;
                dt.StavHracaHistorias.InsertOnSubmit(sth);
                dt.SubmitChanges();
                ret = true;
            }
        }
        finally
        { }
        return ret;
    }

    public bool saveHistory(decimal DynamicPropertyTotal)
    {
        bool ret = false;
        sth = new StavHracaHistoria();
        try
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                sth.PrijemMuz = ST.PrijemMuz;
                sth.PrijemZena = ST.PrijemZena;
                sth.Prijem = ST.Prijem;
                sth.SessionID = ST.SessionID;
                sth.Vek = ST.Vek;
                sth.PocetDeti = ST.PocetDeti;
                sth.Vydaje = ST.Vydaje;
                sth.Najomne = ST.Najomne;
                sth.CurrentPeriod = ST.CurrentPeriod;
                sth.CashFlow = ST.CashFlow;
                sth.MajetokHotovost = ST.MajetokHotovost;
                sth.FondyPenaznehoTrhu = ST.FondyPenaznehoTrhu;
                sth.SpotrebitelskeUvery = ST.SpotrebitelskeUvery;
                sth.Ciel1 = ST.Ciel1;
                sth.Ciel2 = ST.Ciel2;
                sth.Ciel3 = ST.Ciel3;
                sth.Ciel1Id = ST.Ciel1Id;
                sth.Ciel2Id = ST.Ciel2Id;
                sth.Ciel3Id = ST.Ciel3Id;
                sth.SplnenyCiel1 = ST.SplnenyCiel1;
                sth.SplnenyCiel2 = ST.SplnenyCiel2;
                sth.SplnenyCiel3 = ST.SplnenyCiel3;
                sth.MajetokDynamicSpolu = DynamicPropertyTotal;
                sth.DatumZapisu = DateTime.Now;
                dt.StavHracaHistorias.InsertOnSubmit(sth);
                dt.SubmitChanges();
                ret = true;
            }
        }
        finally
        { }
        return ret;
    }
    public List<StavHracaHistoria> GetCleanHistory(string SessionId)
    {
        List<StavHracaHistoria> ret = null;
        try
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                ret = dt.GetUserStatusHistoriaOrdered(SessionId).ToList<StavHracaHistoria>();
                List<int> toremove = new List<int>();
                int position = 1000000;

                foreach (var item in ret)
                {
                    
                    if (item.CurrentPeriod == position)
                    {
                        toremove.Add(item.Id);
                    }
                    else
                    {
                        position = item.CurrentPeriod;
                    }
                }
                foreach (var itt in toremove)
                {
                    ret.RemoveAll(item => item.Id == itt);
                }
            }
        }
        finally
        { }
        return ret;


    }


    public bool SaveUserStatus()
    {
        bool ret = false;
        try
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                StavHraca CurrentStatus = null;

                CurrentStatus = (from a in dt.StavHracas
                                 where a.SessionID == ST.SessionID
                                 select a).FirstOrDefault();

                CurrentStatus.PrijemMuz = ST.PrijemMuz;
                CurrentStatus.PrijemZena = ST.PrijemZena;
                CurrentStatus.Prijem = ST.Prijem;
                CurrentStatus.SessionID = ST.SessionID;
                CurrentStatus.Vek = ST.Vek;
                CurrentStatus.PocetDeti = ST.PocetDeti;
                CurrentStatus.Vydaje = ST.Vydaje;
                CurrentStatus.Najomne = ST.Najomne;
                CurrentStatus.CurrentPeriod = ST.CurrentPeriod;
                CurrentStatus.CashFlow = ST.CashFlow;
                CurrentStatus.MajetokHotovost = ST.MajetokHotovost;
                CurrentStatus.FondyPenaznehoTrhu = ST.FondyPenaznehoTrhu;
                CurrentStatus.SpotrebitelskeUvery = ST.SpotrebitelskeUvery;
                CurrentStatus.Ciel1 = ST.Ciel1;
                CurrentStatus.Ciel2 = ST.Ciel2;
                CurrentStatus.Ciel3 = ST.Ciel3;
                CurrentStatus.Ciel1Id = ST.Ciel1Id;
                CurrentStatus.Ciel2Id = ST.Ciel2Id;
                CurrentStatus.Ciel3Id = ST.Ciel3Id;
                CurrentStatus.SplnenyCiel1 = ST.SplnenyCiel1;
                CurrentStatus.SplnenyCiel2 = ST.SplnenyCiel2;
                CurrentStatus.SplnenyCiel3 = ST.SplnenyCiel3;
                CurrentStatus.PopupSwitcher = ST.PopupSwitcher;
                CurrentStatus.InfoSwitcher = ST.InfoSwitcher;
                CurrentStatus.DatumZapisu = DateTime.Now;
                dt.SubmitChanges();
                ret = true;
            }
        }
        finally
        { }
        return ret;
    }

    public bool UpdateFreeCashflow(decimal Amount, bool minus)
    {
        bool ret = false;
        try
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                StavHraca CurrentStatus = null;

                CurrentStatus = (from a in dt.StavHracas
                                 where a.SessionID == ST.SessionID
                                 select a).FirstOrDefault();
                if (minus)
                {
                    CurrentStatus.CashFlow = ST.CashFlow - Amount;
                }
                else
                {
                    CurrentStatus.CashFlow = ST.CashFlow + Amount;
                }

                CurrentStatus.DatumZapisu = DateTime.Now;
                dt.SubmitChanges();
                ret = true;
            }
        }
        finally
        { }
        return ret;
    }

    public bool SaveNewUserProductSettings()
    {
        return false;
    }

    public bool SaveAddUserMajetok()
    {
        return false;
    }

}