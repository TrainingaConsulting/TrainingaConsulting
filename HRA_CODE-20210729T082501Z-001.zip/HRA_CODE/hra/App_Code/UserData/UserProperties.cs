﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserProperties
/// </summary>
public class UserProperties
{

    public UserProperties(string SessionId)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
        }
    }
}