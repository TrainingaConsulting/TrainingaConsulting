﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for UserPayments
/// </summary>
public class FinanceManager
{

    public List<Financie> _financie = null;
    public List<Majetok> _majetok = null;
    public List<Majetok> _majetokToCalculate = null;
    public List<Majetok> _majetokToCalculateByPeriod = null;
    public List<Majetok> _majetokToCalculateByPeriodStatic = null;
    public List<Majetok> _majetokToCalculateByPeriodDynamic = null;
    public List<StavHracaProdukty> _produkty = null;
    public List<StavHracaProdukty> _CurrentProdukty = null;
    public List<StavHracaUdalosti> _ZoznamUdalosti = null;
    public List<FinCache.Udalost> _CurrentUdalosti = null;
    private string _sessionId = "";
    UserStatus _status = null;
    FinCache.FinCache _fch = null;
    public FinanceManager(string SessionId)
    {
        _sessionId = SessionId;
        _CurrentUdalosti = new List<FinCache.Udalost>();
        _fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(SessionId);
        LoadData(SessionId);

    }

    private void LoadData(string SessionId)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            _majetok = dt.GetUserMajetok(SessionId).ToList<Majetok>();
            _produkty = dt.GetUserProductsStatuses(SessionId).ToList<StavHracaProdukty>();
            _ZoznamUdalosti = dt.GetUserUdalostiAno(SessionId).ToList<StavHracaUdalosti>();
            _majetokToCalculate = _majetok.Select(m => m).Where(mo => mo.ComputedPeriodPrice == true & mo.StaticPercentage == 0 & mo.DynamicPercentage == 0).ToList<Majetok>();
            _majetokToCalculateByPeriod = _majetok.Select(m => m).Where(mo => mo.PeriodDuration > 0 & mo.StaticPercentage == 0 & mo.DynamicPercentage == 0).ToList<Majetok>();
            _majetokToCalculateByPeriodStatic = _majetok.Select(m => m).Where(mo => mo.PeriodDuration > 0 & mo.StaticPercentage > 0 & mo.DynamicPercentage == 0).ToList<Majetok>();
            _majetokToCalculateByPeriodDynamic = _majetok.Select(m => m).Where(mo => mo.PeriodDuration > 0 & mo.StaticPercentage == 0 & mo.DynamicPercentage > 0).ToList<Majetok>();
            _CurrentProdukty = _produkty.Select(m => m).Where(mo => mo.Perioda == _status.ST.CurrentPeriod).ToList<StavHracaProdukty>();
            //if (_ZoznamUdalosti != null)
            //{
            //    foreach (var item in _ZoznamUdalosti)
            //    {
            //        var ret = _fch.FinUdalost.Where(o => _ZoznamUdalosti.Any(c => c.idUdalosti == o.id && c.Periodic == true && c.Ano == true & c.PeriodId != _status.ST.CurrentPeriod)).ToList<FinCache.Udalost>();
            //        if (ret != null)
            //        {
            //            FinCache.Udalost ud = null;
            //            ud = ret.FirstOrDefault<FinCache.Udalost>();
            //            _CurrentUdalosti.Add(ud);
            //        }

            //    }
            //}

            _CurrentUdalosti = _fch.FinUdalost.Where(o => _ZoznamUdalosti.Any(c => c.idUdalosti == o.id && c.Periodic == true && c.Ano == true & c.PeriodId != _status.ST.CurrentPeriod)).ToList<FinCache.Udalost>();
        }
    }

    public void recalcMajetok()
    {
        MortageCheck();
        RecalcVynosy();
        RecalcLimitedPeriodValidity();
        RecalcLimitedPeriodValidityStaticINC();
        RecalcLimitedPeriodValidityDynamicINC();
    }

    public void recalcUdalosti()
    {
        Udalosti ud = new Udalosti(_sessionId, true);
        //if (_CurrentUdalosti != null)
        //{
            foreach (var item in _CurrentUdalosti)
            {
                ud.CalculatePeriodicEvent(item);
            }
        //}

    }
    /// <summary>
    /// deletes motgage is it is not used to buy property
    /// </summary>
    private void MortageCheck()
    {
        bool reload = false;
        if (_majetok.Select(m => m).Where(mo => mo.Name == "Hypoteka").Count() > 0)
        {

            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                var mylist = _majetok.Select(m => m).Where(mo => mo.Name == "Hypoteka");
                foreach (var item in mylist)
                {
                    if (!Tools.HracMaMajetok(_status, _fch, 0))
                    {
                        var aa = (from a in dt.Majetoks
                                  where a.id == item.id
                                  select a).FirstOrDefault();
                        if (aa.NumberPeriodRepay == aa.PeriodDuration)
                        {
                            _status.ST.CashFlow = _status.ST.CashFlow - aa.PriceBuy;
                            _status.SaveUserStatus();
                            dt.Majetoks.DeleteOnSubmit(aa);
                            dt.SubmitChanges();
                            reload = true;
                        }
                    }
                }
            }
        }

        LoadData(_sessionId);
    }

    /// <summary>
    /// stops periodic payments if the financiacial products ends
    /// </summary>
    private void RecalcLimitedPeriodValidity()
    {
        foreach (var item in _majetokToCalculateByPeriod)
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                var itt = (from a in dt.Majetoks
                           where a.id == item.id
                           select a).FirstOrDefault();

                itt.PeriodDuration = itt.PeriodDuration - 1;
                if (itt.PeriodDuration == 0)
                {
                    itt.Active = false;
                    item.Active = false;
                }
                dt.SubmitChanges();
            }
            if (item.Active == false)
            {
                Tools.AddEventNotification(_sessionId, _status.ST.CurrentPeriod, item.Name, "Ukončenie produktu - " + item.Name, item.Type);
            }
        }
        decimal count = 0;
        foreach (var item in _majetokToCalculateByPeriod)
        {
            count = count + item.PeriodCFChange ?? 0;
            Tools.AddFinancialNotification(_sessionId, _status.ST.CurrentPeriod, item.Name, "Splatka  " + item.Name, item.Type, item.PeriodCFChange ?? 0, false);

        }
        _status.ST.CashFlow = _status.ST.CashFlow + count;
        _status.SaveUserStatus();
    }

    private void RecalcVynosy()
    {
        foreach (var item in _majetokToCalculate)
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                var cfg = _CurrentProdukty.Select(m => m).Where(mo => mo.KodProduktu == item.Type).FirstOrDefault();
                if (cfg != null)
                {
                    var itt = (from a in dt.Majetoks
                               where a.id == item.id
                               select a).FirstOrDefault();
                    itt.PriceSell = cfg.HodnotaProduktu;
                    itt.PeriodCFChange = cfg.HodnotaVynosu;
                    item.PriceSell = cfg.HodnotaProduktu;
                    item.PeriodCFChange = cfg.HodnotaVynosu;

                    dt.SubmitChanges();
                }
            }
            if (item.PeriodCFChange > 0)
            {
                Tools.AddFinancialNotification(_sessionId, _status.ST.CurrentPeriod, item.Name, "Vynosy -" + item.Name, item.Type, item.PeriodCFChange ?? 0, false);
            }
        }
        decimal count = 0;
        foreach (var item in _majetokToCalculate)
        {
            count = count + item.PeriodCFChange ?? 0;

        }
        _status.ST.CashFlow = _status.ST.CashFlow + count;
        _status.SaveUserStatus();
    }

    private void RecalcLimitedPeriodValidityStaticINC()
    {
        foreach (var item in _majetokToCalculateByPeriodStatic)
        {
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                var itt = (from a in dt.Majetoks
                           where a.id == item.id
                           select a).FirstOrDefault();
                itt.PriceBuy = (itt.PriceBuy + (((_status.ST.CurrentPeriod - item.CurrentPeriod) * Math.Abs(itt.PeriodCFChange ?? 0)) * itt.StaticPercentage));

                decimal vynos = (((_status.ST.CurrentPeriod - item.CurrentPeriod) * Math.Abs(itt.PeriodCFChange ?? 0)) * itt.StaticPercentage);
                Tools.AddFinancialNotification(_sessionId, _status.ST.CurrentPeriod, item.Name, "Vynos poistenia - ", item.Type, vynos, false);

                dt.SubmitChanges();
            }
        }
        decimal count = 0;
        foreach (var item in _majetokToCalculateByPeriodStatic)
        {
            count = count + item.PeriodCFChange ?? 0;
        }
        _status.ST.CashFlow = _status.ST.CashFlow + count;
        _status.SaveUserStatus();
    }

    private void RecalcLimitedPeriodValidityDynamicINC()
    {
        int min = 0;
        int max = 10;
        int rnd = 0;
        Random random;
        foreach (var item in _majetokToCalculateByPeriodDynamic)
        {
            random = new Random();
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                var itt = (from a in dt.Majetoks
                           where a.id == item.id
                           select a).FirstOrDefault();
                min = _fch.FinPoisteniaAll.Select(m => m).Where(poi => poi.Kod == item.Type).Min(t => t.Rand) ?? 0;
                max = _fch.FinPoisteniaAll.Select(m => m).Where(poi => poi.Kod == item.Type).Max(t => t.Rand) ?? 10;
                rnd = random.Next(min, max);
                itt.DynamicPercentage = (_fch.FinPoisteniaAll.Select(m => m).Where(mo => mo.Rand == rnd).FirstOrDefault()).ZiskPerioda ?? 1;
                itt.PriceBuy = (itt.PriceBuy + (((_status.ST.CurrentPeriod - item.CurrentPeriod) * Math.Abs(itt.PeriodCFChange ?? 0)) * itt.DynamicPercentage));

                decimal vynos = (((_status.ST.CurrentPeriod - item.CurrentPeriod) * Math.Abs(itt.PeriodCFChange ?? 0)) * itt.DynamicPercentage);
                Tools.AddFinancialNotification(_sessionId, _status.ST.CurrentPeriod, item.Name, "Vynos poistenia - ", item.Type, vynos, false);

                dt.SubmitChanges();
            }
        }
        decimal count = 0;
        foreach (var item in _majetokToCalculateByPeriodDynamic)
        {
            count = count + item.PeriodCFChange ?? 0;
        }
        _status.ST.CashFlow = _status.ST.CashFlow + count;
        _status.SaveUserStatus();
    }
}