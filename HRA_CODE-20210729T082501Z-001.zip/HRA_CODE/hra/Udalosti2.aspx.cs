﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Udalosti2 : System.Web.UI.Page
{
    Udalosti ud;
    protected void Page_Init(object sender, EventArgs e)
    {
        // vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        info2.Visible = false;
        ud = new Udalosti(Session.SessionID);
        bool UdalostAno = true;
        UserStatus _status = new UserStatus(Session.SessionID);
        Info.InnerHtml = ud._NahodnaUdalost.Popis;
        hdnCode.Value = ud._NahodnaUdalost.id.ToString();

        if (ud.Insured)
        {
            info2.Visible = true;
            UdalostAno = false;
        }
        String strPathAndQuery = HttpContext.Current.Request.Url.PathAndQuery;
        String strUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace(strPathAndQuery, "/") + System.Configuration.ConfigurationManager.AppSettings["LocPath"].ToString();
        ImgUdalost.ImageUrl = strUrl + "App_Themes/Images/Udalosti/" + ud._NahodnaUdalost.PicName;
        //ImgUdalost.ImageUrl = "../App_Themes/Images/Udalosti/" + ud._NahodnaUdalost.PicName;

        if (ud._NahodnaUdalost.Volba == false)
        {
            btnUdalostAno.Visible = false;
            btnUdalostNie.Visible = false;
            btnCloseEvent.Visible = true;

            StavHracaUdalosti ud2 = null;
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                ud2 = new StavHracaUdalosti();
                ud2.idUdalosti = ud._NahodnaUdalost.id;
                ud2.DatumZapisu = DateTime.Now;
                ud2.Kod = ud._NahodnaUdalost.kod;
                ud2.Nazov = ud._NahodnaUdalost.Nazov;
                ud2.SessionID = Session.SessionID;
                ud2.PeriodId = _status.ST.CurrentPeriod;
                ud2.Ano = UdalostAno;
                ud2.EliminatesItSelf = ud._NahodnaUdalost.EliminujeSa;
                if ((ud._NahodnaUdalost.príjem_každé_kolo == 1) || (ud._NahodnaUdalost.výdaj_každé_kolo == 1))
                {
                    ud2.Periodic = true;
                }
                else
                {
                    ud2.Periodic = false;
                }
                dt.StavHracaUdalostis.InsertOnSubmit(ud2);
                dt.SubmitChanges();
            }
            Tools.AddEventNotification(_status.ST.SessionID, _status.ST.CurrentPeriod, "Udalosť", ud._NahodnaUdalost.Nazov, "Udalosť");
        }
        else
        {
            btnUdalostAno.Visible = true;
            btnUdalostNie.Visible = true;
            btnCloseEvent.Visible = false;

            StavHracaUdalosti ud2 = null;
            using (DataClassesDataContext dt = new DataClassesDataContext())
            {
                ud2 = new StavHracaUdalosti();
                ud2.idUdalosti = ud._NahodnaUdalost.id;
                ud2.DatumZapisu = DateTime.Now;
                ud2.Kod = ud._NahodnaUdalost.kod;
                ud2.Nazov = ud._NahodnaUdalost.Nazov;
                ud2.SessionID = Session.SessionID;
                ud2.PeriodId = _status.ST.CurrentPeriod;
                ud2.Ano = UdalostAno;

                ud2.EliminatesItSelf = ud._NahodnaUdalost.EliminujeSa;
                if ((ud._NahodnaUdalost.príjem_každé_kolo == 1) || (ud._NahodnaUdalost.výdaj_každé_kolo == 1))
                {
                    ud2.Periodic = true;
                }
                else
                {
                    ud2.Periodic = false;
                }
                dt.StavHracaUdalostis.InsertOnSubmit(ud2);
                dt.SubmitChanges();
            }
            Tools.AddEventNotification(_status.ST.SessionID, _status.ST.CurrentPeriod, "Udalosť", ud._NahodnaUdalost.Nazov, "Udalosť");
        }
    }
    [System.Web.Services.WebMethod]
    public static string VolbaAno(string session)
    {
        String ret = "ano";
        UserStatus _status = new UserStatus(session);
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            var ud3 = dt.GetUserUdalost(session, _status.ST.CurrentPeriod).FirstOrDefault();
            if (ud3.Kod == "dedicstvo")
            {
                ud3.Ano = false;
                ud3.Periodic = true;
            }
            else
            {
                ud3.Ano = false;
            }


            dt.SubmitChanges();
        }

        return ret;
    }
    [System.Web.Services.WebMethod]
    public static string VolbaNie(string session)
    {
        String ret = "nie";
        UserStatus _status = new UserStatus(session);
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            var ud3 = dt.GetUserUdalost(session, _status.ST.CurrentPeriod).FirstOrDefault();
            if (ud3.Kod == "dedicstvo")
            {
                ud3.Ano = true;
                ud3.Periodic = false;
                Udalosti udd = new Udalosti(session, "dedicstvo");
                _status.ST.MajetokHotovost += udd._SpecificUdalost.MAJETOKPrijem;
                _status.SaveUserStatus();
                _status.saveHistory();
            }
            else
            {
                ud3.Ano = true;
            }
            dt.SubmitChanges();
        }

        return ret;
    }
}