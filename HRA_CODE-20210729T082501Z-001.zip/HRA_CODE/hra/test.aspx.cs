﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class test : System.Web.UI.Page
{
    FinCache.FinCache fch = null;
    Dictionary<Int64, int> spread = new Dictionary<long, int>();
    Udalosti ud;
    protected void Page_Load(object sender, EventArgs e)
    {
        GraphMaker grap = new GraphMaker(this.Page);
        //grap.preparegraph();
        //List<StavHracaHistoria>
        Response.Redirect("GameEnd2.aspx");

        //fch = FinCache.FinCache.GetInstance();

        //decimal tt = -99.99m + 15;

        //Label1.Text = tt.ToString("0.##");

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        System.Diagnostics.Stopwatch sw = System.Diagnostics.Stopwatch.StartNew();

        //ud = new Udalosti();

        sw.Stop();

        //Label1.Text = ud._NahodnaUdalost.Nazov  + "        " + ud._NahodnaUdalost.id.ToString();

        // Label1.Text = nahoda.ToString()  + "        " + NahodnaUdalost.id.ToString();
        
        //TextBox1.Text = NahodnaUdalost.Nazov;
        //Label2.Text = sw.Elapsed.Milliseconds.ToString();
        //Random random = new Random();
        //Label1.Text = random.Next(1, 20);
    }

    private static readonly Random random = new Random();

    //private static double RandomNumberBetween(double minValue, double maxValue)
    //{
    //    var next = random.NextDouble();

    //    return minValue + (next * (maxValue - minValue));
    //}



    protected void Button4_Click(object sender, EventArgs e)
    {
        GraphMaker grap = new GraphMaker(this.Page);
        //grap.preparegraph();
        Response.Redirect("GameEnd2.aspx");
    }
}