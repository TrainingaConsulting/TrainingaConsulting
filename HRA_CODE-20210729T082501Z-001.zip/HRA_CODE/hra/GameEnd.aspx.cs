﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GameEnd : System.Web.UI.Page
{
    FinCache.FinCache fch = null;
    UserStatus _status = null;
    StavHracaHistoria _FirstStatus = null;
    FinDlhopisy dlh = null;
    FinPodiely pod = null;
    FinAkcie akc = null;
    FinStavebneSporenia SSP = null;
    FinUvery UVR = null;
    FinPoistenia POI = null;
    List<StavHracaUdalosti> _udalosti = null;

    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
        fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(Session.SessionID);
        _FirstStatus = _status.GetFirstStatus(Session.SessionID);

        dlh = new FinDlhopisy(_status.ST.CurrentPeriod, Session.SessionID);
        pod = new FinPodiely(_status.ST.CurrentPeriod, Session.SessionID);
        akc = new FinAkcie(_status.ST.CurrentPeriod, Session.SessionID);
        SSP = new FinStavebneSporenia(_status.ST.CurrentPeriod, Session.SessionID);
        UVR = new FinUvery(_status.ST.CurrentPeriod, Session.SessionID);
        POI = new FinPoistenia(_status.ST.CurrentPeriod, Session.SessionID);

        lblFreeCashFlow.Text = (_FirstStatus.CashFlow ?? 0).ToString("# ##0");
        lblAge.Text = _FirstStatus.Vek.ToString();
        lblChildren.Text = _FirstStatus.PocetDeti.ToString();
        lblPodielovy.Text = "0";
        LblDlhopisovy.Text = "0";
        lblAkcie.Text = "0";
        lblSS.Text = "0";
        lblHypoteka.Text = "0";
        lblSU.Text = "0";
        lblUP.Text = "0";
        lblZP.Text = "0";


        lblFreeCashFlowEnd.Text = (_status.ST.CashFlow ?? 0).ToString("# ##0");
        lblAgeEnd.Text = _status.ST.Vek.ToString();
        lblChildrenEnd.Text = _status.ST.PocetDeti.ToString();
        lblPodielovyEnd.Text = pod.GetNumberOFMajetok();
        LblDlhopisovyEnd.Text = dlh.GetNumberOFMajetok();
        lblAkcieEnd.Text = akc.GetNumberOFMajetok();
        lblSSEnd.Text = SSP.GetNumberOFMajetok();
        lblHypotekaEnd.Text = UVR.GetNumberOFMajetok("HP");
        lblSUEnd.Text = UVR.GetNumberOFMajetok("SU");
        lblUPEnd.Text = POI.GetNumberOFMajetok("Urazove");
        lblZPEnd.Text = POI.GetNumberOFMajetok("Zivotne");

        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            _udalosti = dt.GetUserUdalosti(Session.SessionID).OrderBy(m => m.Id).ToList<StavHracaUdalosti>();

        }

        if (_udalosti != null)
        {
            foreach (var item in _udalosti)
            {
                bltUdalosti.Items.Add(new ListItem { Text = item.Nazov, Value = item.Nazov });
            }
        }

        if (_status.ST.SplnenyCiel1 == true & _status.ST.SplnenyCiel2 == true & _status.ST.SplnenyCiel3 == true )
        {
            DivSplneneCiele.Visible = true;
        }
        else
        {
            DivSplneneCiele.Visible = false;
        }
    }


    protected void btnNext_Click(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
        SessionIDManager manager = new SessionIDManager();

        string newID = manager.CreateSessionID(Context);
        bool redirected = false;
        bool isAdded = false;
        manager.SaveSessionID(Context, newID, out redirected, out isAdded);
        Response.Redirect("Default.aspx");
    }


}