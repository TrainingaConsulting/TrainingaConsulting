﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using System.IO;

public partial class Game : System.Web.UI.Page
{
    FinCache.FinCache fch = null;
    UserStatus _status = null;
    StavHracaHistoria _FirstStatus = null;
    FinDlhopisy dlh = null;
    FinPodiely pod = null;
    FinAkcie akc = null;
    FinStavebneSporenia SSP = null;
    FinUvery UVR = null;
    FinPoistenia POI = null;
    List<StavHracaUdalosti> _udalosti = null;

    protected void Page_Init(object sender, EventArgs e)
    {
         //vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
        hdn1.Value = Session.SessionID;
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
        fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(Session.SessionID);
        _FirstStatus = _status.GetFirstStatus(Session.SessionID);

        dlh = new FinDlhopisy(_status.ST.CurrentPeriod, Session.SessionID);
        pod = new FinPodiely(_status.ST.CurrentPeriod, Session.SessionID);
        akc = new FinAkcie(_status.ST.CurrentPeriod, Session.SessionID);
        SSP = new FinStavebneSporenia(_status.ST.CurrentPeriod, Session.SessionID);
        UVR = new FinUvery(_status.ST.CurrentPeriod, Session.SessionID);
        POI = new FinPoistenia(_status.ST.CurrentPeriod, Session.SessionID);

        lblFreeCashFlow.Text = (_FirstStatus.CashFlow ?? 0).ToString("# ##0");
        lblAge.Text = _FirstStatus.Vek.ToString();
        lblChildren.Text = _FirstStatus.PocetDeti.ToString();
        lblPodielovy.Text = "0";
        LblDlhopisovy.Text = "0";
        lblAkcie.Text = "0";
        lblSS.Text = "0";
        lblHypoteka.Text = "0";
        lblSU.Text = "0";
        lblUP.Text = "0";
        lblZP.Text = "0";
        lblVydajeValue.Text = (_FirstStatus.Vydaje ?? 0).ToString("# ##0");
        lblNajomneValue.Text = (_FirstStatus.Najomne ?? 0).ToString("# ##0");

        lblFreeCashFlowEnd.Text = (_status.ST.CashFlow ?? 0).ToString("# ##0");
        lblAgeEnd.Text = _status.ST.Vek.ToString();
        lblAgeValue.Text = _status.ST.Vek.ToString();
        lblChildrenEnd.Text = _status.ST.PocetDeti.ToString();
        lblPodielovyEnd.Text = pod.GetNumberOFMajetok();
        LblDlhopisovyEnd.Text = dlh.GetNumberOFMajetok();
        lblAkcieEnd.Text = akc.GetNumberOFMajetok();
        lblSSEnd.Text = SSP.GetNumberOFMajetok();
        lblHypotekaEnd.Text = UVR.GetNumberOFMajetok("HP");
        lblSUEnd.Text = UVR.GetNumberOFMajetok("SU");
        lblUPEnd.Text = POI.GetNumberOFMajetok("Urazove");
        lblZPEnd.Text = POI.GetNumberOFMajetok("Zivotne");
        lblNajomneEnd.Text = (_status.ST.Najomne ?? 0).ToString("# ##0");
        lblVydajeEnd.Text = (_status.ST.Vydaje ?? 0).ToString("# ##0");

        lblCiel1.Text = _status.ST.Ciel1;
        lblCiel2.Text = _status.ST.Ciel2;
        lblCiel3.Text = _status.ST.Ciel3;
        lblCiel1Cena.Text = ": - " + (fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(_status.ST.Ciel1Id.ToString())).FirstOrDefault().Price ?? 0).ToString("# ##0") + " €";
        lblCiel2Cena.Text = ": - " + (fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(_status.ST.Ciel2Id.ToString())).FirstOrDefault().Price ?? 0).ToString("# ##0") + " €";
        lblCiel3Cena.Text = ": - " + (fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(_status.ST.Ciel3Id.ToString())).FirstOrDefault().Price ?? 0).ToString("# ##0") + " €";


        if (_status.ST.Vek < 26)
        {
            divContentLeft3.Attributes["Class"] = "divContentLeft3";
        }
        if (_status.ST.Vek > 25 & _status.ST.Vek < 40)
        {
            divContentLeft3.Attributes["Class"] = "divContentLeft32";
        }
        if (_status.ST.Vek > 39 & _status.ST.Vek < 50)
        {
            divContentLeft3.Attributes["Class"] = "divContentLeft33";
        }
        if (_status.ST.Vek > 49 & _status.ST.Vek < 65)
        {
            divContentLeft3.Attributes["Class"] = "divContentLeft34";
        }
        if (_status.ST.Vek > 64)
        {
            divContentLeft3.Attributes["Class"] = "divContentLeft35";
        }

        CheckMajetok();


        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            _udalosti = dt.GetUserUdalosti(Session.SessionID).OrderBy(m => m.Id).ToList<StavHracaUdalosti>();

        }

        //if (_udalosti != null)
        //{
        //    foreach (var item in _udalosti)
        //    {
        //        bltUdalosti.Items.Add(new ListItem { Text = item.Nazov, Value = item.Nazov });
        //    }
        //}

        //if (_status.ST.SplnenyCiel1 == true & _status.ST.SplnenyCiel2 == true & _status.ST.SplnenyCiel3 == true)
        //{
        //    DivSplneneCiele.Visible = true;
        //}
        //else
        //{
        //    DivSplneneCiele.Visible = false;
        //}
        if (File.Exists(this.Server.MapPath("~/Graphs/") + this.Session.SessionID + "_Graf.jpg"))
        {
            divGraf.Style["background-image"] = "url(Graphs/" + this.Session.SessionID + "_Graf.jpg)";
        }
    }

    protected void btnNext_Click(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
        SessionIDManager manager = new SessionIDManager();

        string newID = manager.CreateSessionID(Context);
        bool redirected = false;
        bool isAdded = false;
        manager.SaveSessionID(Context, newID, out redirected, out isAdded);
        Response.Redirect("Default.aspx");
    }
    public void CheckMajetok()
    {
        //_status = new UserStatus(Session.SessionID);
        //_fch = FinCache.FinCache.GetInstance();
        if (_status.ST.SplnenyCiel1)
        {
            divOK1.Visible = true;
            divBad1.Visible = false;
        }
        else
        {
            divOK1.Visible = false;
            divBad1.Visible = true;
        }
        if (_status.ST.SplnenyCiel2)
        {
            divOK2.Visible = true;
            divBad2.Visible = false;
        }
        else
        {
            divOK2.Visible = false;
            divBad2.Visible = true;
        }
        if (_status.ST.SplnenyCiel3)
        {
            divOK3.Visible = true;
            divBad3.Visible = false;
        }
        else
        {
            divOK3.Visible = false;
            divBad3.Visible = true;
        }
    }

    [System.Web.Services.WebMethod]
    public static string PopupSwitcher(string session)
    {
        String ret = "true";
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            int temp = (from a in dt.FeedBacks
                        where a.SessionId == session
                        select a).Count();
            if (temp > 0)
            {
                ret = "false";
            }
        }
        return ret;
    }
}