﻿$(document).ready(function () {
    jQuery(':input').keyup(function () {
        this.value = this.value.replace(/[^0-9]/g, '');
    });
    $('#imgCash').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            //text: 'I look very similar to a Google Maps tooltip!',
            text:"",
            ajax: {
                url: 'Forms/Other/infMoney.html',
                loading: false
            }
        },
        position: {
            my: 'right center',
            at: 'bottom center', // at the bottom right of...
            target: $('#imgCash') // my target
        },
        style: {
            name: 'light',
            widget: true, 
            def: true, 
            tip: {
                border: 1,
                width: 200,
                height: 180
            }
        },
        show: 'click'
    });
    $('#imgRental').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infRental.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgRental') // my target
        },
        style: {
            widget: true,
            def: false,
            tip: {
                corner: 'top right',
                mimic: 'bottom right',
                border: 1,
                width: 200,
                height: 180
            }
        },
        show: 'click'
    });
    $('#imgAge').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infAge.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgAge') // my target
        },
        style: {
            widget: true,
            def: false,
        },
        show: 'click'
    });
    $('#imgChildren').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infChildren.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgChildren') // my target
        },
        style: {
            widget: true,
            def: false,
        },
        show: 'click'
    });
    $('#imgExpenses').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infExpenses.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgExpenses') // my target
        },
        style: {
            widget: true,
            def: false,
        },
        show: 'click'
    });
    $('#imgFreeCashFlow').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infFeeCashFlow.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgFreeCashFlow') // my target
        },
        style: {
            widget: true,
            def: false,
        },
        show: 'click'
    });
    $('#imgManSalary').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infManSalary.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgManSalary') // my target
        },
        style: {
            widget: true,
            def: false,
        },
        show: 'click'
    });
    $('#imgWomanSalary').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infWomanSalary.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgWomanSalary') // my target
        },
        style: {
            widget: true,
            def: false,
        },
        show: 'click'
    });
    $('#imgGoal1').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infGoals.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgGoal1') // my target
        },
        style: {
            widget: true,
            def: false,
        },
        show: 'click'
    });
    $('#imgGoal2').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infGoals.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgGoal2') // my target
        },
        style: {
            widget: true,
            def: false,
        },
        show: 'click'
    });
    $('#imgGoal3').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infGoals.html',
                loading: false
            }
        },
        position: {
            my: 'top left',
            at: 'bottom left', // at the bottom right of...
            target: $('#imgGoal3') // my target
        },
        style: {
            widget: true,
            def: false,
        },
        show: 'click'
    });
});



