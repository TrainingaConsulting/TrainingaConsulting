﻿$(document).ready(function () {
    $('[id$=ddLoanType]').bind('change', function () {

        var obj = {};
        obj.session = $("[id$='hdn1']").val();
        obj.LoanType = $("[id$='ddLoanType']").val();
        var dataString = JSON.stringify(obj);

        $.ajax({
            type: "POST",
            url: "Forms/Products/Uvery.aspx/GetLoans",
            data: dataString,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                var targets = msg.d;

                $("#ddLoadCategory").empty()
                $.each(targets, function (index, ddLoanTypeData) {

                    $("#ddLoadCategory").append($("<option></option>").val(ddLoanTypeData.LoanId).html(ddLoanTypeData.LoanName));
                });
                $('#ddLoadCategory').trigger('change');
                //$('#ddLoanVyska').trigger('change');
            },

            error: function (msgx) {

                alert(Text(msgx));
                //alert("An error has occurred during processing your request.");
            }
        });

    });
});


$(document).ready(function () {
    $('[id$=ddLoadCategory]').bind('change', function () {

        var obj = {};
        obj.LoanCategory = $("[id$='ddLoadCategory']").val();
        obj.LoanType = $("[id$='ddLoanType']").val();
        var dataString = JSON.stringify(obj);

        $.ajax({
            type: "POST",
            url: "Forms/Products/Uvery.aspx/GetLoanTypes",
            data: dataString,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                var targets = msg.d;

                $("#ddLoanVyska").empty()
                $.each(targets, function (index, ddLoanTypeData) {

                    $("#ddLoanVyska").append($("<option></option>").val(ddLoanTypeData.LoanId).html(ddLoanTypeData.LoanName));
                });
                $('#ddLoanVyska').trigger('change');
            },

            error: function (msgx) {

                alert(Text(msgx));
                //alert("An error has occurred during processing your request.");
            }
        });

    });
});

$(document).ready(function () {
    $('[id$=ddLoanVyska]').bind('change', function () {

        var obj = {};
        obj.LoanCategory = $("[id$='ddLoadCategory']").val();
        obj.LoanType = $("[id$='ddLoanType']").val();
        obj.loanAmount = $("[id$='ddLoanVyska']").val();
        var dataString = JSON.stringify(obj);

        $.ajax({
            type: "POST",
            url: "Forms/Products/Uvery.aspx/CalculateLoans",
            data: dataString,
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                var targets = msg.d;

                $.each(targets, function (index, ddLoanTypeDetail) {
                    $("#lblUrok").text(ddLoanTypeDetail.Urok);
                    $("#lblPeriod").text(ddLoanTypeDetail.Periods);
                    $("#lblPeriodPrice").text(ddLoanTypeDetail.PeriodPrice);
                });
            },

            error: function (msgx) {

                alert(Text(msgx));
                //alert("An error has occurred during processing your request.");
            }
        });

    });
});


$(document).on("click", "#btnBuyLoan", function () {
    var obj = {};
    obj.Count = 1; // $("[id$='ddBuyDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Financie.aspx/BuyPodiel",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }

            else {
                $('#lblPocetPodielov').text(data.d);
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});

$(document).on("click", "#btnCalcLoan", function () {
    var obj = {};
    obj.Count = 1; // $("[id$='ddBuyDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Uvery.aspx/BuyPodiel",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }

            else {
                $('#lblPocetPodielov').text(data.d);
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});