﻿$(document).ready(function () {
    jQuery(':input').keyup(function () {
        this.value = this.value.replace(/[^0-9]/g, '');
    });
    $('#imgCash').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            //text: 'I look very similar to a Google Maps tooltip!',
            text: "",
            ajax: {
                url: 'Forms/Other/infMoney.aspx',
                loading: false
            }
        },
        position: {
            my: 'right center',
            at: 'bottom center', // at the bottom right of...
            target: 'mouse',//$('#imgCash'), // my target
            adjust: {
                x: -30,
                y: 3,
                mouse: false
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 300,
                height: 200
            }
        },
        show: 'click'
    });
    $('#imgFunds').qtip({
        // Simply use an HTML img tag within the HTML string
        content: {
            //text: 'I look very similar to a Google Maps tooltip!',
            text: "",
            ajax: {
                url: 'Forms/Other/infFunds.aspx',
                loading: false
            }
        },
        position: {
            my: 'right center',
            at: 'bottom center', // at the bottom right of...
            target: 'mouse',//$('#imgCash'), // my target
            adjust: {
                x: -30,
                y: 3,
                mouse: false
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 300,
                height: 200
            }
        },
        show: 'click'
    });
    $('#imgLoans').qtip({
        content: {
            text: "",
            ajax: {
                url: 'Forms/Other/infLoans.aspx',
                loading: false
            }
        },
        position: {
            my: 'right center',
            at: 'bottom center', 
            target: 'mouse',
            adjust: {
                x: -30,
                y: 3,
                mouse: false
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 300,
                height: 200
            }
        },
        show: 'click'
    });
    $('#imgRental').qtip({
        content: {
            text: "",
            ajax: {
                url: 'Forms/Other/infRental.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgRental'),
            adjust: {
                x: 10,
                y: 0,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
    $('#imgAge').qtip({
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infAge.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgAge'),
            adjust: {
                x: 10,
                y: 0,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
    $('#imgChildren').qtip({
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infChildren.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgChildren'),
            adjust: {
                x: 10,
                y: 0,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
    $('#imgExpenses').qtip({
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infExpenses.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgExpenses'),
            adjust: {
                x: 10,
                y: -10,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
    $('#imgFreeCashFlow').qtip({
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infFeeCashFlow.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgFreeCashFlow'), 
            adjust: {
                x: 10,
                y: 0,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
    $('#imgManSalary').qtip({
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infManSalary.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgManSalary'),
            adjust: {
                x: 10,
                y: 0,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
    $('#imgWomanSalary').qtip({
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infWomanSalary.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgWomanSalary'),
            adjust: {
                x: 10,
                y: 0,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
    $('#imgGoal1').qtip({
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infGoals.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgGoal1'),
            adjust: {
                x: 10,
                y: -3,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
    $('#imgGoal2').qtip({
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infGoals.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgGoal2'),
            adjust: {
                x: 10,
                y: -3,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
    $('#imgGoal3').qtip({
        content: {
            text: '',
            ajax: {
                url: 'Forms/Other/infGoals.aspx',
                loading: false
            }
        },
        position: {
            my: 'left center',
            at: 'bottom center',
            target: $('#imgGoal3'),
            adjust: {
                x: 10,
                y: -3,
                mouse: false,
            }
        },
        style: {
            name: 'light',
            widget: true,
            def: true,
            tip: {
                border: 1,
                width: 'auto',
                height: 'auto'
            }
        },
        show: 'click'
    });
});
$(document).on("click", "#btnCloseEvent", function () { parent.location.href = parent.location.href; });
$(document).on("click", "#btnCloseEventNoPB", function () {
    parent.location.href = parent.location.href; e.preventDefault();
});

