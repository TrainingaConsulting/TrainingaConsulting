﻿
//--------------------Dlhopisy
$("#pnlBtnDlhopis").off("click");
$(document).on("click", "#pnlBtnDlhopis", function () {
    var url = "Forms/Products/Dlhopis2.aspx";
    //var q1 = "?EmpId=" + $('#hvID').val();
    //url = url + q1;
    $('#DivSwitchHolder').dialog({
        modal: true,
        overlay: true,
        open: function () {
            $(this).load(url);
        },
        close: function (e) {
            $(this).empty();
            $(this).dialog('destroy');
            $(this).remove();
            parent.location.href = parent.location.href;
        },
        height: 360,
        width: 664,
        title: 'Otvorené podielové fondy - Dlhopisové'
    });
    $(".ui-widget-header").hide();
    $(".ui-widget-overlay").attr('style', 'background-color: #000; opacity:0; z-index:1;');
})
$("#btnBuyDlhopis").off("click");
$(document).on("click", "#btnBuyDlhopis", function () {
    var obj = {};
    obj.Count = 1; // $("[id$='ddBuyDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Dlhopis2.aspx/BuyDlhopis",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }

            else {
                var res = data.d.split(';');

                $('#lblPocetDlhopisov').text(res[0]); //.text(data.d);
                if (res[1] == '1')
                {
                    $('#lblOk').text(res[2]);
                    $("#divOK").fadeIn(400).delay(800).fadeOut(400);
                }
                else
                {
                    $('#lblBad').text(res[2]);
                    $("#divBad").fadeIn(400).delay(800).fadeOut(400);
                }
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$("#btnBuyDlhopis").off("click");
$(document).on("click", "#btnBuyDlhopis", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Dlhopis2.aspx/pocetmoznychdlhopisov",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }
            else {
                $('#lblMaxDlhopis').text(data.d);
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$("#btnSellDlhopis").off("click");
$(document).on("click", "#btnSellDlhopis", function () {
    var obj = {};
    obj.Count = 1;//$("[id$='ddSellDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Dlhopis2.aspx/SellDlhopis",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }
            else {
                var res = data.d.split(';');

                $('#lblPocetDlhopisov').text(res[0]); //.text(data.d);
                if (res[1] == '1')
                {
                    $('#lblOk').text(res[2]);
                    $("#divOK").fadeIn(400).delay(800).fadeOut(400);
                }
                else
                {
                    $('#lblBad').text(res[2]);
                    $("#divBad").fadeIn(400).delay(800).fadeOut(400);
                }
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$("#btnSellDlhopis").off("click");
$(document).on("click", "#btnSellDlhopis", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Dlhopis2.aspx/pocetmoznychdlhopisov",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }
            else {
                $('#lblMaxDlhopis').text(data.d);

            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$.fn.FormIsValidDlhopis = function () {

    var res = 0;

    ////validate Salary
    //var rege = /^(\d+(?:[\.\,]\d{2})?)$/;
    //if (!rege.test($("[id$='txtSalary']").val())) {
    //    res = res + 1;
    //    alert('Pole mzda môže obsahovať len desatinné čísla oddelené čiarkou alebo bodkou!');
    //}

    ////validate EmployeeID
    //var obj = {};
    //obj.PersonId = $("[id$='txtId']").val();
    //obj.EmployeeID = $("[id$='txtEmpID']").val();

    //// validate EmployeeID - ci je vyplnene
    //if (obj.EmployeeID == "") {
    //    res = res + 1;
    //    alert('Pole ID zamestnanca je povinné!');
    //}
    //else //validate EmployeeID - ci je uz pridelene
    //{
    //    var dataString = JSON.stringify(obj);
    //    $.ajax({
    //        type: "POST",
    //        dataType: "json",
    //        contentType: "application/json; charset=utf-8",
    //        url: "Forms/Employees/EditEmployee.aspx/IsValidEmployeeId",
    //        data: dataString,
    //        success: function (data) {
    //            if (data.d == 0) {
    //                res = res + 1;
    //                alert('Toto ID zamestnanca nemôžete použiť!');
    //            }
    //        },

    //        error: function (e, ts, et) {
    //            alert(e.text);
    //        }
    //    });
    //}

    return res;
};

//--------------------Poistenia
$("#pnlBtnPoistenia").off("click");
$(document).on("click", "#pnlBtnPoistenia", function () {
    var url = "Forms/Products/Poistenia2.aspx";

    $('#DivSwitchHolder').dialog({
        resizable: false,
        modal: true,
        open: function () {
            $(this).load(url);
        },
        close: function (e) {
            $(this).empty();
            $(this).dialog('destroy');
            parent.location.href = parent.location.href;
        },
        height: 415,
        width:665,
        title: 'Poistenie'
    });
    $(".ui-widget-header").hide();
    $(".ui-widget-overlay").attr('style', 'background-color: #000; opacity:0; z-index:1;');
})
$(document).on("change", "#ddInsuranceType", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();
    obj.InsuranceType = $("[id$='ddInsuranceType']").val();
    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        url: "Forms/Products/Poistenia2.aspx/GetInsurances",
        data: dataString,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            var targets = msg.d;
            $.each(targets, function (index, insurance) {
                $("#lblYearPay").text(insurance.VkladRok);
                $("#lblPeriodPay").text(insurance.VkladPerioda);
                $("#lblZisk").text(insurance.Nazov);
                $("#lblTargetInsurancePrice").text(insurance.CielovaSumaPoistenia).formatNumber({ format: "#,###", locale: "cz" });
            });
        },

        error: function (msgx) {

            alert(Text(msgx));
            //alert("An error has occurred during processing your request.");
        }
    });

});
$("#btnbtnBuyInsurance").off("click");
$(document).on("click", "#btnBuyInsurance", function () {
    var obj = {};
    obj.Count = 1;//$("[id$='ddSellDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();
    obj.InsuranceType = $("[id$='ddInsuranceType']").val();


    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Poistenia2.aspx/BuyInsurance",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }
            else {
                var res = data.d.split(';');

               //.text(data.d);
                if (res[1] == '1')
                {
                    $('#lblOk').text(res[2]);
                    $('#lblPocetPoisteni').text(res[0]);
                    $("#divOK").fadeIn(400).delay(800).fadeOut(400);
                }
                else
                {
                    $('#lblBad').text(res[2]);
                    $("#divBad").fadeIn(400).delay(800).fadeOut(400);
                }
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$(document).on("click", "#btnSellInsurance", function () {
    var obj = {};
    obj.Count = 1;//$("[id$='ddSellDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();
    obj.InsuranceType = $("[id$='ddInsuranceType']").val();


    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Poistenia2.aspx/CancelInsurance",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }
            else {
                var res = data.d.split(';');

               
                if (res[1] == '1')
                {
                    $('#lblOk').text(res[2]);
                    $('#lblPocetPoisteni').text(res[0]); //.text(data.d);
                    $("#divOK").fadeIn(400).delay(800).fadeOut(400);
                }
                else
                {
                    $('#lblBad').text(res[2]);
                    $("#divBad").fadeIn(400).delay(800).fadeOut(400);
                }
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});

//--------------------Akcie
$("#pnlBtnAkcie").off("click");
$(document).on("click", "#pnlBtnAkcie", function () {
    var url = "Forms/Products/Akcie2.aspx";

    $('#DivSwitchHolder').dialog({

        modal: true,
        open: function () {
            $(this).load(url);
        },
        Ok: function () {

            $("[id*=Button1]").click();

        },
        close: function (e) {
            $(this).empty();
            $(this).dialog('destroy');
            parent.location.href = parent.location.href;
        },
        height: 414,
        width: 665,
        title: 'Otvorené podielové fondy - Akciové'
    });
    $(".ui-widget-header").hide();
    $(".ui-widget-overlay").attr('style', 'background-color: #000; opacity:0; z-index:1;');
})
$("#btnBuyAkcia").off("click");
$(document).on("click", "#btnBuyAkcia", function () {
    var obj = {};
    obj.Count = 1;
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Akcie2.aspx/BuyAkcia",
        data: dataString,
        success: function (data) {
            var res = data.d.split(';');
            if (res[0] == '1')
            {
                $('#lblOk').text(res[1]);
                $("#divOK").fadeIn(400).delay(800).fadeOut(400);
            }
            else
            {
                $('#lblBad').text(res[1]);
                $("#divBad").fadeIn(400).delay(800).fadeOut(400);
            }

        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end lblPocetAkcii
});
$("#btnBuyAkcia").off("click");
$(document).on("click", "#btnBuyAkcia", function () {
    var obj = {};
    obj.Count = 1;
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Akcie2.aspx/BuyAkciaInfo",
        data: dataString,
        success: function (msg) {
            var targets = msg.d;
            $.each(targets, function (index, AkcieInfo) {
                $("#lblPocetAkcii").text(AkcieInfo.Pocet);
                $("#lblAkciaPriceTotal").text(AkcieInfo.Cena);
            });
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end lblPocetAkcii
});
$("#btnBuyAkcia").off("click");
$(document).on("click", "#btnBuyAkcia", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Akcie2.aspx/pocetmoznychakcii",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }

            else {
                $('#lblMaxAkcia').text(data.d);
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});

$("#btnSellAkcia").off("click");
$(document).on("click", "#btnSellAkcia", function () {
    var obj = {};
    obj.Count = 1;//$("[id$='ddSellDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Akcie2.aspx/SellAkcia",
        data: dataString,
        success: function (data) {
            var res = data.d.split(';');
            if (data.d == '1')
            {
                $('#lblOk').text(res[1]);
                $("#divOK").fadeIn(400).delay(800).fadeOut(400);
            }
            else
            {
                $('#lblBad').text(res[1]);
                $("#divBad").fadeIn(400).delay(800).fadeOut(400);
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$("#btnSellAkcia").off("click");
$(document).on("click", "#btnSellAkcia", function () {
    var obj = {};
    obj.Count = 1;//$("[id$='ddSellDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Akcie2.aspx/SellAkciaInfo",
        data: dataString,
        success: function (msg) {
            var targets = msg.d;
            $.each(targets, function (index, AkcieInfo) {
                $("#lblPocetAkcii").text(AkcieInfo.Pocet);
                $("#lblAkciaPriceTotal").text(AkcieInfo.Cena);
            });
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$("#btnSellAkcia").off("click");
$(document).on("click", "#btnSellAkcia", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Akcie2.aspx/pocetmoznychakcii",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }

            else {
                $('#lblMaxAkcia').text(data.d);
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});

//--------------------Sporenie
$("#pnlBtnSporenie").off("click");
$(document).on("click", "#pnlBtnSporenie", function () {
    var url = "Forms/Products/Sporenia2.aspx";
 
    $('#DivSwitchHolder').dialog({

        modal: true,
        resizable: false,
        buttons: {
            //"Zavrieť": function () {
            //    $(this).dialog("close");
            //}
        },
        open: function () {
            $(this).load(url);
        },
        close: function (e) {
            $(this).empty();
            $(this).dialog('destroy');
            parent.location.href = parent.location.href;
        },
        height: 380,
        width: 670,
        title: 'Sporenie'
    });
    $(".ui-widget-header").hide();
    $(".ui-widget-overlay").attr('style', 'background-color: #000; opacity:0; z-index:1;');
})
$(document).on("change", "#ddBuildLoanType", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();
    obj.LoanType = $("[id$='ddBuildLoanType']").val();
    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        url: "Forms/Products/Sporenia2.aspx/GetBuildLoans",
        data: dataString,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            var targets = msg.d;
            $.each(targets, function (index, ssloan) {
                $("#lblBuildLoanAmount").text(ssloan.VyskaUveru).formatNumber({ format: "#,###", locale: "cz" });
                $("#lblBuildLoanPeriods").text(ssloan.PocetVkladov);
                $("#lblBuildLoanPeriodRePay").text(ssloan.VkladObdobie).formatNumber({ format: "#,###", locale: "cz" });
            });
        },

        error: function (msgx) {

            alert(Text(msgx));
            //alert("An error has occurred during processing your request.");
        }
    });

});
$(document).on("click", "#btnBuyBuildLoan", function () {
    var obj = {};
    obj.Count = 1; // $("[id$='ddBuyDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();
    obj.LoanType = $("[id$='ddBuildLoanType']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Sporenia2.aspx/BuyBuildLoan",
        data: dataString,
        success: function (data) {
            var res = data.d.split(';');
            if (res[0] == '1')
            {
                $('#lblOk').text(res[1]);
                $("#divOK").fadeIn(400).delay(800).fadeOut(400);
            }
            else
            {
                $('#lblBad').text(res[1]);
                $("#divBad").fadeIn(400).delay(800).fadeOut(400);
            }

        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});

//--------------------Peniaze
$("#pnlBtnPeniaze").off("click");
$(document).on("click", "#pnlBtnPeniaze", function () {
    var url = "Forms/Products/Financie2.aspx";

    $('#DivSwitchHolder').dialog({

        modal: true,
        open: function () {
            $(this).load(url);
        },
        close: function (e) {
            $(this).empty();
            $(this).dialog('destroy');
            parent.location.href = parent.location.href;
        },
        height: 360,
        width: 665,
        title: 'Otvorené podielové fondy - Peňažné'
    });
    $(".ui-widget-header").hide();
    $(".ui-widget-overlay").attr('style', 'background-color: #000; opacity:0; z-index:1;');
})
$("#btnBuyPodiel").off("click");
$(document).on("click", "#btnBuyPodiel", function () {
    var obj = {};
    obj.Count = 1; // $("[id$='ddBuyDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Financie2.aspx/BuyPodiel",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }
            else {
                var res = data.d.split(';');

                $('#lblPocetPodielov').text(res[0]); //.text(data.d);
                if (res[1] == '1')
                {
                    $('#lblOk').text(res[2]);
                    $("#divOK").fadeIn(400).delay(800).fadeOut(400);
                }
                else
                {
                    $('#lblBad').text(res[2]);
                    $("#divBad").fadeIn(400).delay(800).fadeOut(400);
                }
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$("#btnBuyPodiel").off("click");
$(document).on("click", "#btnBuyPodiel", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Financie2.aspx/pocetmoznychpodielov",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }

            else {
                $('#lblMaxPodiel').text(data.d);

            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});

$("#btnSellpodiel").off("click");
$(document).on("click", "#btnSellpodiel", function () {
    var obj = {};
    obj.Count = 1;//$("[id$='ddSellDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Financie2.aspx/SellPodiel",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }
            else {
                var res = data.d.split(';');

                $('#lblPocetPodielov').text(res[0]); 
                if (res[1] == '1')
                {
                    $('#lblOk').text(res[2]);
                    $("#divOK").fadeIn(400).delay(800).fadeOut(400);
                }
                else
                {
                    $('#lblBad').text(res[2]);
                    $("#divBad").fadeIn(400).delay(800).fadeOut(400);
                }
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$("#btnSellpodiel").off("click");
$(document).on("click", "#btnSellpodiel", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Financie2.aspx/pocetmoznychpodielov",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }

            else {
                $('#lblMaxPodiel').text(data.d);

            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});

//--------------------Uvery
$("#pnlBtnUvery").off("click");
$(document).on("click", "#pnlBtnUvery", function () {
    var url = "Forms/Products/Uvery2.aspx";

    $('#DivSwitchHolder').dialog({

        modal: true,

        open: function () {
            $(this).load(url);
        },
        close: function (e) {
            $(this).empty();
            $(this).dialog('destroy');
            parent.location.href = parent.location.href;
        },
        height: 505,
        width: 660,
        title: 'Sporenie'
    });
    $(".ui-widget-header").hide();
    $(".ui-widget-overlay").attr('style', 'background-color: #000; opacity:0; z-index:1;');
});
$(document).on("change", "#ddLoanType", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();
    obj.LoanType = $("[id$='ddLoanType']").val();
    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        url: "Forms/Products/Uvery2.aspx/GetLoans",
        data: dataString,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            var targets = msg.d;

            $("#ddLoadCategory").empty()
            $.each(targets, function (index, ddLoanTypeData) {

                $("#ddLoadCategory").append($("<option></option>").val(ddLoanTypeData.LoanId).html(ddLoanTypeData.LoanName));
            });
            $('#ddLoadCategory').trigger('change');
            //$('#ddLoanVyska').trigger('change');
        },

        error: function (msgx) {

            alert(Text(msgx));
            //alert("An error has occurred during processing your request.");
        }
    });

});
$(document).on("change", "#ddLoadCategory", function () {
    var obj = {};
    obj.LoanCategory = $("[id$='ddLoadCategory']").val();
    obj.LoanType = $("[id$='ddLoanType']").val();
    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        url: "Forms/Products/Uvery2.aspx/GetLoanTypes",
        data: dataString,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            var targets = msg.d;

            $("#ddLoanVyska").empty()
            $.each(targets, function (index, ddLoanTypeData) {

                $("#ddLoanVyska").append($("<option></option>").val(ddLoanTypeData.LoanId).html(ddLoanTypeData.LoanName));
            });
            $('#ddLoanVyska').trigger('change');
        },

        error: function (msgx) {

            alert(Text(msgx));
            //alert("An error has occurred during processing your request.");
        }
    });
});
$(document).on("change", "#ddLoanVyska", function () {
    var obj = {};
    obj.LoanCategory = $("[id$='ddLoadCategory']").val();
    obj.LoanType = $("[id$='ddLoanType']").val();
    obj.loanAmount = $("[id$='ddLoanVyska']").val();
    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        url: "Forms/Products/Uvery2.aspx/CalculateLoans",
        data: dataString,
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            var targets = msg.d;

            $.each(targets, function (index, ddLoanTypeDetail) {
                $("#lblUrok").text(ddLoanTypeDetail.Urok);
                $("#lblPeriod").text(ddLoanTypeDetail.Periods);
                $("#lblPeriodPrice").text(ddLoanTypeDetail.PeriodPrice);
            });
        },

        error: function (msgx) {

            alert(Text(msgx));
            //alert("An error has occurred during processing your request.");
        }
    });
});
$(document).on("click", "#btnCalcLoan", function () {
    var obj = {};
    obj.Count = 1; // $("[id$='ddBuyDlhopis']").val();
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Uvery2.aspx/BuyPodiel",
        data: dataString,
        success: function (data) {
            if (data.d.indexOf("Error") != -1) {
            }

            else {
                $('#lblPocetPodielov').text(data.d);
            }
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$(document).on("click", "#btnBuyLoan", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();
    obj.LoanCategory = $("[id$='ddLoadCategory']").val();
    obj.LoanType = $("[id$='ddLoanType']").val();
    obj.loanAmount = $("[id$='ddLoanVyska']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Forms/Products/Uvery2.aspx/BuyLoan",
        data: dataString,
        success: function (data) {
            var res = data.d.split(';');
            if (res[0] == '1')
            {
                $('#lblOk').text(res[1]);
                $("#divOK").fadeIn(400).delay(800).fadeOut(400);
            }
            else
            {
                $('#lblBad').text(res[1]);
                $("#divBad").fadeIn(400).delay(800).fadeOut(400);
            }

        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});


//--------------------Udalosti
$(document).on("click", "#btnUdalostAno", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Udalosti2.aspx/VolbaAno",
        data: dataString,
        success: function (data) {
            // alert(data.d);

            var objj = {};
            objj.Count = 1;
            objj.session = $("[id$='hdn1']").val();

            var dataString = JSON.stringify(obj);

            $.ajax({
                type: "POST",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                url: "Game.aspx/recalc",
                data: dataString,
                success: function (data) {
                    if (data.d.indexOf("Error") != -1) {
                    }

                    else {

                    }
                },
                error: function (e, ts, et) {
                    alert(e.text);
                }
            });

            parent.location.href = parent.location.href;
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$(document).on("click", "#btnUdalostNie", function () {
    var obj = {};
    obj.session = $("[id$='hdn1']").val();

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "Udalosti2.aspx/VolbaNie",
        data: dataString,
        success: function (data) {
            var objj = {};
            objj.Count = 1;
            objj.session = $("[id$='hdn1']").val();

            var dataString = JSON.stringify(obj);

            $.ajax({
                type: "POST",
                dataType: "json",
                contentType: "application/json; charset=utf-8",
                url: "Game.aspx/recalc",
                data: dataString,
                success: function (data) {
                    if (data.d.indexOf("Error") != -1) {
                    }

                    else {

                    }
                },
                error: function (e, ts, et) {
                    alert(e.text);
                }
            });
            parent.location.href = parent.location.href;
        },
        error: function (e, ts, et) {
            alert(e.text);
        }
    }); //ajax func end
});
$(document).on("click", "#btnCloseEvent", function () { parent.location.href = parent.location.href; });
$(document).on("click", "#btnCloseSaveFeedback", function () {
    var obj = {};
    obj.session = $("[id$='hdns']").val();
    obj.txtEbook = $("[id$='txtEbook']").val();
    obj.txtFeedBackGood = $("[id$='txtFeedBackGood']").val();
    obj.txtFeedBackBad = $("[id$='txtFeedBackBad']").val();
    obj.txtContact = $("[id$='txtContact']").val();

    if ($('#chkInfo').is(":checked")) {
        obj.Checked = 'true';
    }
    else
    {
        obj.Checked = 'false';
    }

    var dataString = JSON.stringify(obj);

    $.ajax({
        type: "POST",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "InfoFeedBack.aspx/InsertAndClose",
        data: dataString,
        success: function (data) {
            var res = data.d.split(';');
            parent.location.href = parent.location.href;
        },
        error: function (e, ts, et) {
            alert(e.text);
            parent.location.href = parent.location.href;
        }
    }); //ajax func end


    
});
//$(document).on("click", "#btnCloseEventNoPB", function () { });
$("#PnlInfo").off("click");
$(document).on("click", "#PnlInfo", function () {
    var url = "Forms/Products/PeriodInfo2.aspx";
    $('#DivSwitchHolder2').dialog({
        modal: true,
        overlay: true,
        resizable:false,
        open: function () {
            $(this).load(url);
        },
        close: function (e) {
            $(this).empty();
            $(this).dialog('destroy');
            parent.location.href = parent.location.href;
        },
        height: 430,
        width: 668,
        title: 'Info'
    });
    $(".ui-widget-header").hide();
    $(".ui-widget-overlay").attr('style', 'background-color: #000; opacity:0; z-index:1;');
    //$('#myDialogId').css('overflow', 'hidden');
})
$('a.close-reveal-modal').trigger('click');
$(document).ready(function () {
    $("#buyWarning").delay(800).fadeOut(800);
}); 
$(document).ready(function () {
    $(window).on('beforeunload', function () {
        document.cookie = "keepscroll=" + $(window).scrollTop();
    });
    var cs = document.cookie ? document.cookie.split(';') : [];
    var i = 0, cslen = cs.length;
    for (; i < cs.length; i++) {
        var c = cs[i].split('=');
        if (c[0].trim() == "keepscroll") {
            $(window).scrollTop(parseInt(c[1]));
            break;
        }
    }
});