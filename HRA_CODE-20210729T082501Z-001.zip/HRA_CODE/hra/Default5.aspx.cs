﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default5 : System.Web.UI.Page
{
    FinCache.FinCache fch = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
        fch = FinCache.FinCache.GetInstance();
        if (!Page.IsPostBack)
        {
            SessionIDManager manager = new SessionIDManager();
            manager.RemoveSessionID(System.Web.HttpContext.Current);
            var newId = manager.CreateSessionID(System.Web.HttpContext.Current);
            var isRedirected = true;
            var isAdded = true;
            manager.SaveSessionID(System.Web.HttpContext.Current, newId, out isRedirected, out isAdded);

            FillCiele();
        }
        
    }

    private void FillCiele()
    {
        ddCiel1.Items.Clear();
        ddCiel2.Items.Clear();
        ddCiel3.Items.Clear();
        foreach (var item in fch.FinCieleAll)
        {
            if ((item.Type == "Dovolenka") | (item.Type == "Nehnuteľnost"))
            {
                ListItem li = new ListItem(item.Name, item.id.ToString());
                ddCiel1.Items.Add(li);
                ddCiel2.Items.Add(li);
            }
            //if (item.Type == "Finančná nezávislosť")
            else
            {
                ListItem li = new ListItem(item.Name, item.id.ToString());
                ddCiel3.Items.Add(li);

            }
        }
    }
    protected void btnNext_Click(object sender, EventArgs e)
    {
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            StavHraca st = new StavHraca();
            StavHracaHistoria sth = new StavHracaHistoria();

            st.PrijemMuz = Convert.ToDecimal((txtManSalary.Text == "") ? "0" : txtManSalary.Text );
            st.PrijemZena = Convert.ToDecimal((txtWomanSalary.Text == "") ? "0" : txtWomanSalary.Text);
            st.Prijem = st.PrijemMuz + st.PrijemZena;
            st.SessionID = Session.SessionID;
            st.Vek = Convert.ToInt16((txtAge.Text == "") ? "0" : txtAge.Text);
            st.PocetDeti = Convert.ToInt16((txtChildren.Text == "") ? "0" : txtChildren.Text);
            st.Vydaje = Convert.ToDecimal((txtExpenses.Text == "") ? "0" : txtExpenses.Text);
            st.Najomne = Convert.ToDecimal((txtRental.Text == "") ? "0" : txtRental.Text);
            st.CurrentPeriod = 0;
            st.CashFlow = Convert.ToDecimal((txtFreeCashFlow.Text == "") ? "0" : txtFreeCashFlow.Text);
            st.MajetokHotovost = Convert.ToDecimal((txtCash.Text == "") ? "0" : txtCash.Text);
            st.FondyPenaznehoTrhu = Convert.ToDecimal((txtFunds.Text == "") ? "0" : txtFunds.Text);
            st.SpotrebitelskeUvery = Convert.ToDecimal(txtConsumerLoans.Text);
            st.Ciel1 = ddCiel1.SelectedItem.Text;
            st.Ciel2 = ddCiel2.SelectedItem.Text;
            st.Ciel3 = ddCiel3.SelectedItem.Text;
            st.Ciel1Id = int.Parse(ddCiel1.SelectedItem.Value);
            st.Ciel2Id = int.Parse(ddCiel2.SelectedItem.Value);
            st.Ciel3Id = int.Parse(ddCiel3.SelectedItem.Value);
            st.SplnenyCiel1 = false;
            st.SplnenyCiel2 = false;
            st.SplnenyCiel3 = false;
            st.DatumZapisu = DateTime.Now;

            sth.PrijemMuz = st.PrijemMuz;
            sth.PrijemZena = st.PrijemZena;
            sth.Prijem = st.PrijemMuz + st.PrijemZena;
            sth.SessionID = Session.SessionID;
            sth.Vek =st.Vek;
            sth.PocetDeti = st.PocetDeti;
            sth.Vydaje = st.Vydaje;
            sth.Najomne = st.Najomne;
            sth.CurrentPeriod = 0;
            sth.CashFlow =  st.CashFlow;
            sth.MajetokHotovost = st.MajetokHotovost;
            sth.FondyPenaznehoTrhu = st.FondyPenaznehoTrhu;
            sth.SpotrebitelskeUvery = st.SpotrebitelskeUvery;
            sth.Ciel1 = ddCiel1.SelectedItem.Text;
            sth.Ciel2 = ddCiel2.SelectedItem.Text;
            sth.Ciel3 = ddCiel3.SelectedItem.Text;
            sth.Ciel1Id = int.Parse(ddCiel1.SelectedItem.Value);
            sth.Ciel2Id = int.Parse(ddCiel2.SelectedItem.Value);
            sth.Ciel3Id = int.Parse(ddCiel3.SelectedItem.Value);
            sth.SplnenyCiel1 = false;
            sth.SplnenyCiel2 = false;
            sth.SplnenyCiel3 = false;
            sth.DatumZapisu = DateTime.Now;


            dt.StavHracas.InsertOnSubmit(st);
            dt.StavHracaHistorias.InsertOnSubmit(sth);

            dt.SubmitChanges();
        }
        FinGame gm = new FinGame(Session.SessionID, 0);
        gm.AddStatuses(0);
        Response.Redirect("Game.aspx");
    }


    protected void txtManSalary_TextChanged(object sender, EventArgs e)
    {
        ddCiel1.Items.Add(new ListItem { Text = "sasd", Value = "11" });
    }

    [System.Web.Services.WebMethod()]
    public static List<FinCache.Ciele> GetLanguageList(string sum)
    {
        FinCache.FinCache fch = FinCache.FinCache.GetInstance();
        List<FinCache.Ciele> ciele = fch.FinCieleAll;
        return ciele;
    }
}