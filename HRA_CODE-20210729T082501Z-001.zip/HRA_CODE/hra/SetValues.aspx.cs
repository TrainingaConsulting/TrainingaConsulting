﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;
using System.Web.SessionState;

public partial class SetValues : System.Web.UI.Page
{
    FinCache.FinCache fch = null;
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
        string StrId = Request.QueryString["id"];
        int id = GetId(StrId);
        redirectCards(id);

        fch = FinCache.FinCache.GetInstance();
        if (Page.IsPostBack)
        {
            ReadFields();
        }
        if (!Page.IsPostBack)
        {
            SessionIDManager manager = new SessionIDManager();
            manager.RemoveSessionID(System.Web.HttpContext.Current);
            var newId = manager.CreateSessionID(System.Web.HttpContext.Current);
            var isRedirected = true;
            var isAdded = true;
            manager.SaveSessionID(System.Web.HttpContext.Current, newId, out isRedirected, out isAdded);
            SetFields();
            FillCiele();
        }
        String strPathAndQuery = HttpContext.Current.Request.Url.PathAndQuery;
        String strUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace(strPathAndQuery, "/") + System.Configuration.ConfigurationManager.AppSettings["LocPath"].ToString();
        //ImgInfoCashFlow.ImageUrl = strUrl + "App_Themes/Images/infoWhite.png";
        //ImgInfoExpenses.ImageUrl = strUrl + "App_Themes/Images/infoWhite.png";
        //ImgInfoGoals.ImageUrl = strUrl + "App_Themes/Images/infoWhite.png";
        //ImgInfoIncome.ImageUrl = strUrl + "App_Themes/Images/infoWhite.png";
        //ImgInfoMoney.ImageUrl = strUrl + "App_Themes/Images/infoWhite.png";
        //ImgInfoRental.ImageUrl = strUrl + "App_Themes/Images/infoWhite.png";
    }

    private void ReadFields()
    {
        Session["txtManSalary"] = txtManSalary.Text;
        Session["txtWomanSalary"] = txtWomanSalary.Text;
        Session["txtFreeCashFlow"] = txtFreeCashFlow.Text;
        Session["txtAge"] = txtAge.Text;
        Session["txtRental"] = txtRental.Text;
        Session["txtChildren"] = txtChildren.Text;
        Session["txtExpenses"] = txtExpenses.Text;
        Session["txtCash"] = txtCash.Text;
        Session["txtFunds"] = txtFunds.Text;
        Session["txtConsumerLoans"] = txtConsumerLoans.Text;
    }

    private void SetFields()
    {
        if (Session["txtManSalary"] != null)
        {
            txtManSalary.Text = (string)Session["txtManSalary"];
        }
        if (Session["txtWomanSalary"] != null)
        {
            txtWomanSalary.Text = (string)Session["txtWomanSalary"];
        }
        if (Session["txtFreeCashFlow"] != null)
        {
            txtFreeCashFlow.Text = (string)Session["txtFreeCashFlow"];
        }
        if (Session["txtAge"] != null)
        {
            txtAge.Text = (string)Session["txtAge"];
        }
        if (Session["txtRental"] != null)
        {
            txtRental.Text = (string)Session["txtRental"];
        }
        if (Session["txtChildren"] != null)
        {
            txtChildren.Text = (string)Session["txtChildren"];
        }
        if (Session["txtExpenses"] != null)
        {
            txtExpenses.Text = (string)Session["txtExpenses"];
        }
        if (Session["txtCash"] != null)
        {
            txtCash.Text = (string)Session["txtCash"];
        }
        if (Session["txtFunds"] != null)
        {
            txtFunds.Text = (string)Session["txtFunds"];
        }
        if (Session["txtConsumerLoans"] != null)
        {
            txtConsumerLoans.Text = (string)Session["txtConsumerLoans"];
        }
    }

    private void redirectCards(int id)
    {
        FinGame gm;
        switch (id)
        {
            case 1:
                using (DataClassesDataContext dt = new DataClassesDataContext())
                {
                    StavHraca st = new StavHraca();
                    StavHracaHistoria sth = new StavHracaHistoria();

                    st.PrijemMuz = 690;
                    st.PrijemZena = 420;
                    st.Prijem = st.PrijemMuz + st.PrijemZena;
                    st.SessionID = Session.SessionID;
                    st.Vek = 28;
                    st.PocetDeti = 1;
                    st.Vydaje = 620;
                    st.Najomne = 200;
                    st.CurrentPeriod = 0;
                    st.CashFlow = 300;
                    st.MajetokHotovost = 5000;
                    st.FondyPenaznehoTrhu = 1000;
                    st.SpotrebitelskeUvery = 1700;
                    st.Ciel1 = "3-izbový byt";
                    st.Ciel2 = "Dovolenka v Paríži";
                    st.Ciel3 = "Finančná nezávislosť";
                    st.Ciel1Id = 4;
                    st.Ciel2Id = 12;
                    st.Ciel3Id = 19;
                    st.SplnenyCiel1 = false;
                    st.SplnenyCiel2 = false;
                    st.SplnenyCiel3 = false;
                    st.DatumZapisu = DateTime.Now;

                    sth.PrijemMuz = st.PrijemMuz;
                    sth.PrijemZena = st.PrijemZena;
                    sth.Prijem = st.PrijemMuz + st.PrijemZena;
                    sth.SessionID = Session.SessionID;
                    sth.Vek = st.Vek;
                    sth.PocetDeti = st.PocetDeti;
                    sth.Vydaje = st.Vydaje;
                    sth.Najomne = st.Najomne;
                    sth.CurrentPeriod = 0;
                    sth.CashFlow = st.CashFlow;
                    sth.MajetokHotovost = st.MajetokHotovost;
                    sth.FondyPenaznehoTrhu = st.FondyPenaznehoTrhu;
                    sth.SpotrebitelskeUvery = st.SpotrebitelskeUvery;
                    sth.Ciel1 = st.Ciel1;
                    sth.Ciel2 = st.Ciel2;
                    sth.Ciel3 = st.Ciel3;
                    sth.Ciel1Id = st.Ciel1Id;
                    sth.Ciel2Id = st.Ciel2Id;
                    sth.Ciel3Id = st.Ciel3Id;
                    sth.SplnenyCiel1 = false;
                    sth.SplnenyCiel2 = false;
                    sth.SplnenyCiel3 = false;
                    sth.DatumZapisu = DateTime.Now;


                    dt.StavHracas.InsertOnSubmit(st);
                    dt.StavHracaHistorias.InsertOnSubmit(sth);

                    dt.SubmitChanges();
                }
                gm = new FinGame(Session.SessionID, 0);
                gm.AddStatuses(0);
                Response.Redirect("Game.aspx");
                break;
            case 2:
                using (DataClassesDataContext dt = new DataClassesDataContext())
                {
                    StavHraca st = new StavHraca();
                    StavHracaHistoria sth = new StavHracaHistoria();

                    st.PrijemMuz = 810;
                    st.PrijemZena = 490;
                    st.Prijem = st.PrijemMuz + st.PrijemZena;
                    st.SessionID = Session.SessionID;
                    st.Vek = 30;
                    st.PocetDeti = 1;
                    st.Vydaje = 680;
                    st.Najomne = 300;
                    st.CurrentPeriod = 0;
                    st.CashFlow = 207;
                    st.MajetokHotovost = 8000;
                    st.FondyPenaznehoTrhu = 1500;
                    st.SpotrebitelskeUvery = 6000;
                    st.Ciel1 = "nadštandardný byt";
                    st.Ciel2 = "Dovolenka v Karibiku";
                    st.Ciel3 = "Finančná nezávislosť";
                    st.Ciel1Id = 5;
                    st.Ciel2Id = 16;
                    st.Ciel3Id = 20;
                    st.SplnenyCiel1 = false;
                    st.SplnenyCiel2 = false;
                    st.SplnenyCiel3 = false;
                    st.DatumZapisu = DateTime.Now;

                    sth.PrijemMuz = st.PrijemMuz;
                    sth.PrijemZena = st.PrijemZena;
                    sth.Prijem = st.PrijemMuz + st.PrijemZena;
                    sth.SessionID = Session.SessionID;
                    sth.Vek = st.Vek;
                    sth.PocetDeti = st.PocetDeti;
                    sth.Vydaje = st.Vydaje;
                    sth.Najomne = st.Najomne;
                    sth.CurrentPeriod = 0;
                    sth.CashFlow = st.CashFlow;
                    sth.MajetokHotovost = st.MajetokHotovost;
                    sth.FondyPenaznehoTrhu = st.FondyPenaznehoTrhu;
                    sth.SpotrebitelskeUvery = st.SpotrebitelskeUvery;
                    sth.Ciel1 = st.Ciel1;
                    sth.Ciel2 = st.Ciel2;
                    sth.Ciel3 = st.Ciel3;
                    sth.Ciel1Id = st.Ciel1Id;
                    sth.Ciel2Id = st.Ciel2Id;
                    sth.Ciel3Id = st.Ciel3Id;
                    sth.SplnenyCiel1 = false;
                    sth.SplnenyCiel2 = false;
                    sth.SplnenyCiel3 = false;
                    sth.DatumZapisu = DateTime.Now;


                    dt.StavHracas.InsertOnSubmit(st);
                    dt.StavHracaHistorias.InsertOnSubmit(sth);

                    dt.SubmitChanges();
                }
                gm = new FinGame(Session.SessionID, 0);
                gm.AddStatuses(0);
                Response.Redirect("Game.aspx");
                break;
            case 3:
                using (DataClassesDataContext dt = new DataClassesDataContext())
                {
                    StavHraca st = new StavHraca();
                    StavHracaHistoria sth = new StavHracaHistoria();

                    st.PrijemMuz = 900.00M;
                    st.PrijemZena = 530.00M;
                    st.Prijem = st.PrijemMuz + st.PrijemZena;
                    st.SessionID = Session.SessionID;
                    st.Vek = 32;
                    st.PocetDeti = 1;
                    st.Vydaje = 750.00M;
                    st.Najomne = 250.00M;
                    st.CurrentPeriod = 0;
                    st.CashFlow = 500.00M;
                    st.MajetokHotovost = 9000.00M;
                    st.FondyPenaznehoTrhu = 6000.00M;
                    st.SpotrebitelskeUvery = 7000.00M;
                    st.Ciel1 = "Rodinný dom";
                    st.Ciel2 = "Dovolenka v Keni";
                    st.Ciel3 = "Finančná nezávislosť";
                    st.Ciel1Id = 6;
                    st.Ciel2Id = 17;
                    st.Ciel3Id = 20;
                    st.SplnenyCiel1 = false;
                    st.SplnenyCiel2 = false;
                    st.SplnenyCiel3 = false;
                    st.DatumZapisu = DateTime.Now;

                    sth.PrijemMuz = st.PrijemMuz;
                    sth.PrijemZena = st.PrijemZena;
                    sth.Prijem = st.PrijemMuz + st.PrijemZena;
                    sth.SessionID = Session.SessionID;
                    sth.Vek = st.Vek;
                    sth.PocetDeti = st.PocetDeti;
                    sth.Vydaje = st.Vydaje;
                    sth.Najomne = st.Najomne;
                    sth.CurrentPeriod = 0;
                    sth.CashFlow = st.CashFlow;
                    sth.MajetokHotovost = st.MajetokHotovost;
                    sth.FondyPenaznehoTrhu = st.FondyPenaznehoTrhu;
                    sth.SpotrebitelskeUvery = st.SpotrebitelskeUvery;
                    sth.Ciel1 = st.Ciel1;
                    sth.Ciel2 = st.Ciel2;
                    sth.Ciel3 = st.Ciel3;
                    sth.Ciel1Id = st.Ciel1Id;
                    sth.Ciel2Id = st.Ciel2Id;
                    sth.Ciel3Id = st.Ciel3Id;
                    sth.SplnenyCiel1 = false;
                    sth.SplnenyCiel2 = false;
                    sth.SplnenyCiel3 = false;
                    sth.DatumZapisu = DateTime.Now;


                    dt.StavHracas.InsertOnSubmit(st);
                    dt.StavHracaHistorias.InsertOnSubmit(sth);

                    dt.SubmitChanges();
                }
                gm = new FinGame(Session.SessionID, 0);
                gm.AddStatuses(0);
                Response.Redirect("Game.aspx");
                break;
            default:
                break;
        }
    }

    private static int GetId(string StrId)
    {
        int id;
        if (StrId != null)
        {
            if (!int.TryParse(StrId, out id))
            {
                id = 0;
            }
        }
        else
        {
            id = 0;
        }
        return id;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            StavHraca st = new StavHraca();
            StavHracaHistoria sth = new StavHracaHistoria();

            st.PrijemMuz = Convert.ToDecimal((txtManSalary.Text == "") ? "0" : txtManSalary.Text);
            st.PrijemZena = Convert.ToDecimal((txtWomanSalary.Text == "") ? "0" : txtWomanSalary.Text);
            st.Prijem = st.PrijemMuz + st.PrijemZena;
            st.SessionID = Session.SessionID;
            st.Vek = Convert.ToInt16((txtAge.Text == "") ? "0" : txtAge.Text);
            st.PocetDeti = Convert.ToInt16((txtChildren.Text == "") ? "0" : txtChildren.Text);
            st.Vydaje = Convert.ToDecimal((txtExpenses.Text == "") ? "0" : txtExpenses.Text);
            st.Najomne = Convert.ToDecimal((txtRental.Text == "") ? "0" : txtRental.Text);
            st.CurrentPeriod = 0;
            st.CashFlow = Convert.ToDecimal((txtFreeCashFlow.Text == "") ? "0" : txtFreeCashFlow.Text);
            st.MajetokHotovost = Convert.ToDecimal((txtCash.Text == "") ? "0" : txtCash.Text);
            st.FondyPenaznehoTrhu = Convert.ToDecimal((txtFunds.Text == "") ? "0" : txtFunds.Text);
            st.SpotrebitelskeUvery = Convert.ToDecimal((txtConsumerLoans.Text == "") ? "0" : txtFunds.Text);
            st.Ciel1 = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(ddCiel1.SelectedItem.Value)).FirstOrDefault().Name); //ddCiel1.SelectedItem.Text;
            st.Ciel2 = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(ddCiel2.SelectedItem.Value)).FirstOrDefault().Name); //ddCiel2.SelectedItem.Text;
            st.Ciel3 = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(ddCiel3.SelectedItem.Value)).FirstOrDefault().Name); //ddCiel3.SelectedItem.Text;
            st.Ciel1Id = int.Parse(ddCiel1.SelectedItem.Value);
            st.Ciel2Id = int.Parse(ddCiel2.SelectedItem.Value);
            st.Ciel3Id = int.Parse(ddCiel3.SelectedItem.Value);
            st.SplnenyCiel1 = false;
            st.SplnenyCiel2 = false;
            st.SplnenyCiel3 = false;
            st.DatumZapisu = DateTime.Now;

            sth.PrijemMuz = st.PrijemMuz;
            sth.PrijemZena = st.PrijemZena;
            sth.Prijem = st.PrijemMuz + st.PrijemZena;
            sth.SessionID = Session.SessionID;
            sth.Vek = st.Vek;
            sth.PocetDeti = st.PocetDeti;
            sth.Vydaje = st.Vydaje;
            sth.Najomne = st.Najomne;
            sth.CurrentPeriod = 0;
            sth.CashFlow = st.CashFlow;
            sth.MajetokHotovost = st.MajetokHotovost;
            sth.FondyPenaznehoTrhu = st.FondyPenaznehoTrhu;
            sth.SpotrebitelskeUvery = st.SpotrebitelskeUvery;
            sth.Ciel1 =  (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(ddCiel1.SelectedItem.Value)).FirstOrDefault().Name); //ddCiel1.SelectedItem.Text;
            sth.Ciel2 = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(ddCiel2.SelectedItem.Value)).FirstOrDefault().Name); //ddCiel2.SelectedItem.Text;
            sth.Ciel3 = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(ddCiel3.SelectedItem.Value)).FirstOrDefault().Name); //ddCiel3.SelectedItem.Text;
            sth.Ciel1Id = int.Parse(ddCiel1.SelectedItem.Value);
            sth.Ciel2Id = int.Parse(ddCiel2.SelectedItem.Value);
            sth.Ciel3Id = int.Parse(ddCiel3.SelectedItem.Value);
            sth.SplnenyCiel1 = false;
            sth.SplnenyCiel2 = false;
            sth.SplnenyCiel3 = false;
            sth.DatumZapisu = DateTime.Now;


            dt.StavHracas.InsertOnSubmit(st);
            dt.StavHracaHistorias.InsertOnSubmit(sth);

            dt.SubmitChanges();
        }
        FinGame gm = new FinGame(Session.SessionID, 0);
        gm.AddStatuses(0);
        Response.Redirect("Game.aspx");
    }

    private void FillCiele()
    {
        ddCiel1.Items.Clear();
        ddCiel2.Items.Clear();
        ddCiel3.Items.Clear();
        ListItem lii = new ListItem("---------------Vyberte si prvý cieľ---------------", "---");
        ddCiel1.Items.Add(lii);
        lii = new ListItem("--------------Vyberte si druhý cieľ--------------", "---");
        ddCiel2.Items.Add(lii);
        lii = new ListItem("---------------Vyberte si tretí cieľ---------------", "---");
        ddCiel3.Items.Add(lii);

        foreach (var item in fch.FinCieleAll)
        {
            //if ((item.Type == "Dovolenka") | (item.Type == "Nehnuteľnost"))
            //{
            //    ListItem li = new ListItem(item.Name, item.id.ToString());
            //    ddCiel1.Items.Add(li);
            //    ddCiel2.Items.Add(li);
            //}
            ////if (item.Type == "Finančná nezávislosť")
            //else
            //{
            //    ListItem li = new ListItem(item.Name, item.id.ToString());
            //    ddCiel3.Items.Add(li);

            //}
            if (item.Choicebox == 1)
            {
                ListItem li = new ListItem((item.Price ?? 0).ToString("# ##0") + " €  - " + item.Name, item.id.ToString());
                ddCiel1.Items.Add(li);
            }
            if (item.Choicebox == 2)
            {
                ListItem li = new ListItem((item.Price ?? 0).ToString("# ##0") + " €  - " + item.Name, item.id.ToString());
                ddCiel2.Items.Add(li);
            }
            if (item.Choicebox == 3)
            {
                ListItem li = new ListItem((item.Price ?? 0).ToString("# ##0") + " €  - " + item.Name, item.id.ToString());
                ddCiel3.Items.Add(li);
            }

        }
    }
    [System.Web.Services.WebMethod()]
    public static List<FinCache.Ciele> GetLanguageList(string sum)
    {
        FinCache.FinCache fch = FinCache.FinCache.GetInstance();
        List<FinCache.Ciele> ciele = fch.FinCieleAll;
        return ciele;
    }

}