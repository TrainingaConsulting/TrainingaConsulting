﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Financie2 : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        // vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        hdn1.Value = Session.SessionID;
        UserStatus _status = new UserStatus(Session.SessionID);
        FinPodiely pod = new FinPodiely(_status.ST.CurrentPeriod, Session.SessionID);
        lblPocetPodielov.Text = pod.GetNumberOFMajetok();
        lblPeriod.Text = _status.ST.CurrentPeriod.ToString();
        lblVynos.Text = pod.VynosPodielu().ToString("# ##0");
        lblPodielPrice.Text = pod.CenaPodielu().ToString("# ##0");
        lblMaxPodiel.Text = pod.getNumOfPossibleMajetok().ToString();
    }
    [System.Web.Services.WebMethod]
    public static string pocetmoznychpodielov(string session)
    {
        UserStatus _status = new UserStatus(session);
        FinPodiely pod = new FinPodiely(_status.ST.CurrentPeriod, session);
        return pod.getNumOfPossibleMajetok().ToString();
    }

    [System.Web.Services.WebMethod]
    public static string BuyPodiel(String Count, string session)
    {
        String ret = "";
        Boolean ok = false;
        String InfoMsg = "";
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(session);
        FinPodiely pod = new FinPodiely(_status.ST.CurrentPeriod, session);

        for (int i = 0; i < int.Parse(Count); i++)
        {
            if (pod.getNumOfPossibleMajetok() > 0)
            {
                pod.BuyPodiel(1);
                ok = true;
            }
        }
        ret = pod.GetNumberOFMajetok();
        if (ok)
        {
            InfoMsg = "Schválené";
            return ret + ";1;" + InfoMsg;
        }
        else
        {
            InfoMsg = "Nedostatok finančných prostriedkov";
            return ret + ";0;" + InfoMsg;
        }
    }
    [System.Web.Services.WebMethod]
    public static string SellPodiel(String Count, string session)
    {
        String ret = "";
        Boolean ok = false;
        String InfoMsg = "";
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(session);
        FinPodiely pod = new FinPodiely(_status.ST.CurrentPeriod, session);

        for (int i = 0; i < int.Parse(Count); i++)
        {
            ok = pod.SellPodiel(1);
        }
        ret = pod.GetNumberOFMajetok();
        if (ok)
        {
            InfoMsg = "Schválené";
            return ret + ";1;" + InfoMsg;
        }
        else
        {
            InfoMsg = "Všetky produkty sú predané";
            return ret + ";0;" + InfoMsg;
        }
    }
}