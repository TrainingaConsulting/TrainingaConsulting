﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Forms_Info : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        // vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        //Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        //Response.Cache.SetNoStore();
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }

}