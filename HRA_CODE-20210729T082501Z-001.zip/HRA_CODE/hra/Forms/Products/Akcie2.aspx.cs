﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Akcie2 : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        // vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        hdn1.Value = Session.SessionID;
        UserStatus _status = new UserStatus(Session.SessionID);
        FinAkcie akc = new FinAkcie(_status.ST.CurrentPeriod, Session.SessionID);
        lblPocetAkcii.Text = akc.GetMajetokInfo()[0].Pocet.ToString();
        lblAkciaPriceTotal.Text = akc.GetMajetokInfo()[0].Cena;
        lblPeriod.Text = _status.ST.CurrentPeriod.ToString();
        lblVynos.Text = akc.VynosAkcie().ToString("# ##0");
        lblAkciaPrice.Text = akc.CenaAkcie().ToString("# ##0");
        lblMaxAkcia.Text = akc.getNumOfPossibleMajetok().ToString();
    }

    [System.Web.Services.WebMethod]
    public static string pocetmoznychakcii(string session)
    {
        UserStatus _status = new UserStatus(session);
        FinAkcie akc = new FinAkcie(_status.ST.CurrentPeriod, session);
        return akc.getNumOfPossibleMajetok().ToString();
    }

    [System.Web.Services.WebMethod]
    public static string BuyAkcia(String Count, string session)
    {
        String InfoMsg = "";
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(session);
        FinAkcie akc = new FinAkcie(_status.ST.CurrentPeriod, session);
        if (akc.getNumOfPossibleMajetok() > 0)
        {
            for (int i = 0; i < int.Parse(Count); i++)
            {
                akc.BuyAkcia(1);
                InfoMsg = "Schválené";
            }
            return "1;" + InfoMsg;
        }
        InfoMsg = "Nedostatok finančných prostriedkov";
        return "0;" + InfoMsg;
    }
    [System.Web.Services.WebMethod]
    public static List<FinAkcie.MajetokInfo> BuyAkciaInfo(String Count, string session)
    {

        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(session);
        FinAkcie akc = new FinAkcie(_status.ST.CurrentPeriod, session);
        return akc.GetMajetokInfo();
    }

    [System.Web.Services.WebMethod]
    public static List<FinAkcie.MajetokInfo> SellAkciaInfo(String Count, string session)
    {
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(session);
        FinAkcie akc = new FinAkcie(_status.ST.CurrentPeriod, session);
        return akc.GetMajetokInfo();
    }
    [System.Web.Services.WebMethod]
    public static string SellAkcia(String Count, string session)
    {
        String InfoMsg = "";
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(session);
        FinAkcie akc = new FinAkcie(_status.ST.CurrentPeriod, session);

        for (int i = 0; i < int.Parse(Count); i++)
        {
            if (akc.SellAkcia(1))
            {
                InfoMsg = "Schválené";
                return "1;" + InfoMsg;
            }
            else
            {
                InfoMsg = "Všetky produkty sú predané";
            }
        }
        return "0;" + InfoMsg;
    }
}