﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Poistenia2 : System.Web.UI.Page
{
    FinCache.FinCache _fch = null;
    protected void Page_Init(object sender, EventArgs e)
    {
        // vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        hdn1.Value = Session.SessionID;
        _fch = FinCache.FinCache.GetInstance();
        if (!Page.IsPostBack)
        {
            ListItem li = new ListItem();
            li.Text = "------ Vyber si typ poistenia ------";
            li.Value = "-";
            ddInsuranceType.Items.Add(li);

            foreach (var item in _fch.FinPoisteniaDist)
            {
                li = new ListItem();
                li.Text = item.Nazov;
                li.Value = item.Kod;
                ddInsuranceType.Items.Add(li);
            }
        }

    }




    [System.Web.Services.WebMethod]
    public static List<FinCache.Poistenia> GetInsurances(string session, String InsuranceType)
    {
        FinCache.Poistenia itt = new FinCache.Poistenia();
        List<FinCache.Poistenia> dd = new List<FinCache.Poistenia>();
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();


        if (InsuranceType =="-")
        {
            itt = new FinCache.Poistenia();
            itt.VkladRok = 0;
            itt.VkladPerioda = 0;
            itt.Nazov = "";
            itt.CielovaSumaPoistenia = 0;
            dd.Add(itt);
            return dd;
        }

        itt = (from a in _fch.FinPoisteniaAll where a.Kod == InsuranceType select a).FirstOrDefault();
        itt.Nazov = "0";
        if (itt.Rand > 0)
        {
            itt.Nazov = "Podla investicií.";
        }
        if (itt.Rand == 0)
        {
            if (itt.ZiskPerioda > 0)
            {
                itt.Nazov = ((itt.ZiskPerioda ?? 1) * 100).ToString("0.00") + " %";
            }
            if (itt.ZiskPerioda == 0)
            {
                itt.Nazov = "0";
            }
        }
        itt.VkladPerioda = itt.VkladRok * _fch.GetCiselnikValue("PeriodaRokov").IntValue ?? 3;

        dd.Add(itt);
        return dd;
    }

    [System.Web.Services.WebMethod]
    public static string BuyInsurance(String Count, string session, string InsuranceType)
    {
        String ret = "";
        Boolean ok = false;
        String InfoMsg = "";
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(session);
        FinPoistenia ins = new FinPoistenia(_status.ST.CurrentPeriod, session);
        if (InsuranceType == "-")
        {
            InfoMsg = "Vyberte typ poistenia";
            ret = ins.GetNumberOFMajetok() + ";0;" + InfoMsg;
            return ret;
        }
        for (int i = 0; i < int.Parse(Count); i++)
        {
            if (int.Parse(ins.GetNumberOFMajetok(InsuranceType)) == 0)
            {
                ok = ins.BuyInsurance(InsuranceType);

            }
        }
        ret = ins.GetNumberOFMajetok();
        if (ok)
        {
            InfoMsg = "Schválené";
            return ret + ";1;" + InfoMsg;
        }
        else
        {
            InfoMsg = "Nie je možné získať poistenie.";
            return ret + ";0;" + InfoMsg;
        }

    }
    [System.Web.Services.WebMethod]
    public static string CancelInsurance(String Count, string session, string InsuranceType)
    {
        String ret = "";
        Boolean ok = false;
        String InfoMsg = "";
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(session);
        FinPoistenia ins = new FinPoistenia(_status.ST.CurrentPeriod, session);
        if (InsuranceType == "-")
        {
            InfoMsg = "Vyberte typ poistenia";
            ret = ins.GetNumberOFMajetok() + ";0;" + InfoMsg;
            return ret;
        }
        for (int i = 0; i < int.Parse(Count); i++)
        {
            ok = ins.CancelInsurance(InsuranceType);
        }
        ret = ins.GetNumberOFMajetok();
        if (ok)
        {
            InfoMsg = "Schválené";
            return ret + ";1;" + InfoMsg;
        }
        else
        {
            InfoMsg = "Nemáte toto poistenie";
            return ret + ";0;" + InfoMsg;
        }
    }



}