﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PeriodInfo2 : System.Web.UI.Page
{
    UserStatus _status = null;
    List<HracNotifikacie> _udalosti = null;
    List<HracPlatby> _platby = null;

    protected void Page_Init(object sender, EventArgs e)
    {
        // vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        _status = new UserStatus(Session.SessionID);
        FinAkcie akc = new FinAkcie(_status.ST.CurrentPeriod, _status.ST.SessionID);
        FinDlhopisy dlh = new FinDlhopisy(_status.ST.CurrentPeriod, _status.ST.SessionID);
        FinPodiely pod = new FinPodiely(_status.ST.CurrentPeriod, _status.ST.SessionID);
        String strPathAndQuery = HttpContext.Current.Request.Url.PathAndQuery;
        String strUrl = HttpContext.Current.Request.Url.AbsoluteUri.Replace(strPathAndQuery, "/") + System.Configuration.ConfigurationManager.AppSettings["LocPath"].ToString();
        if (pod.GetPreviousStatus().rand1 > pod.GetActualStatus().rand1)
        {
            imgPod.ImageUrl = strUrl + "App_Themes/Images/SipkaDole.png";
        }
        else
        {
            imgPod.ImageUrl = strUrl + "App_Themes/Images/SipkaHore.png";
        }
        if (akc.GetPreviousStatus().rand1 > akc.GetActualStatus().rand1)
        {
            imgAkc.ImageUrl = strUrl + "App_Themes/Images/SipkaDole.png";
        }
        else
        {
            imgAkc.ImageUrl = strUrl + "App_Themes/Images/SipkaHore.png";
        }
        if (dlh.GetPreviousStatus().rand1 > dlh.GetActualStatus().rand1)
        {
            ImgDlh.ImageUrl = strUrl + "App_Themes/Images/SipkaDole.png";
        }
        else
        {
            ImgDlh.ImageUrl = strUrl + "App_Themes/Images/SipkaHore.png"; // http:/85.248.138.162/finindep/
        }

        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            _udalosti = dt.GetHracPosledneNotifikacie(_status.ST.SessionID, _status.ST.CurrentPeriod).OrderBy(m => m.KodProduktu).ToList();
            _platby = dt.GetHracPoslednePlatby(_status.ST.SessionID, _status.ST.CurrentPeriod).OrderBy(m => m.KodProduktu).ToList();
        }

        if (_udalosti != null)
        {
            foreach (var item in _udalosti)
            {
                bltUdalosti.Items.Add(new ListItem { Text = item.Popis, Value = item.Popis });
            }
        }
        if (_platby != null)
        {
            foreach (var item in _platby)
            {
                bltFinancie.Items.Add(new ListItem { Text = item.Popis + "    " + (item.Suma ?? 0).ToString("0"), Value = item.Popis });
            }
        }
    }

}