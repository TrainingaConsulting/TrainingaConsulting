﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Forms_Products_Sporenia : System.Web.UI.Page
{
    FinCache.FinCache _fch = null;
    protected void Page_Init(object sender, EventArgs e)
    {
        // vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        hdn1.Value = Session.SessionID;
        _fch = FinCache.FinCache.GetInstance();

        if (!Page.IsPostBack)
        {
            ListItem li = new ListItem();
            li.Text = "-";
            li.Value = "-";
            ddBuildLoanType.Items.Add(li);

            foreach (var item in _fch.FinSsAll)
            {
                li = new ListItem();
                li.Text = item.Nazov;
                li.Value = item.Kod;
                ddBuildLoanType.Items.Add(li);
            }
        }
    }

    [System.Web.Services.WebMethod]
    public static List<FinCache.SS> GetBuildLoans(string session, String LoanType)
    {
        FinCache.SS itt = new FinCache.SS();
        List<FinCache.SS> dd = new List<FinCache.SS>();
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();

        itt = (from a in _fch.FinSsAll where a.Kod == LoanType select a).FirstOrDefault();

        dd.Add(itt);
        return dd;
    }
    [System.Web.Services.WebMethod]
    public static string BuyBuildLoan(string session, String LoanType)
    {
        FinStavebneSporenia spor = new FinStavebneSporenia(session);
        if (LoanType == "-")
        {
           return "0"; 
        }
        if (spor.CanBuyBuildLoan(session,LoanType))
        {
            spor.BuyBuildLoan(session, LoanType);
            return "1";
        }
        return "0";
    }
}