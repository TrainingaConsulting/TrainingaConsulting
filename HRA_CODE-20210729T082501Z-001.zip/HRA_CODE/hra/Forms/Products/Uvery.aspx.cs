﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Forms_Products_Uvery : System.Web.UI.Page
{
    protected void Page_Init(object sender, EventArgs e)
    {
        // vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        hdn1.Value = Session.SessionID;

        FinCache.FinCache _fch = null;
        if (!Page.IsPostBack)
        {
            _fch = FinCache.FinCache.GetInstance();
            ListItem li = new ListItem();
            li.Text = "-";
            li.Value = "-";
            ddLoanType.Items.Add(li);


            li = new ListItem();
            li.Text = "Hypotéka";
            li.Value = "hypoteka";
            ddLoanType.Items.Add(li);

            li = new ListItem();
            li.Text = "Spotrebný úver";
            li.Value = "spotrebyuver";
            ddLoanType.Items.Add(li);
        }
    }
    [System.Web.Services.WebMethod]
    public static List<ddLoanTypeData> GetLoans(string session, String LoanType)
    {
        ddLoanTypeData itt = new ddLoanTypeData();
        List<ddLoanTypeData> dd = new List<ddLoanTypeData>();
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        if (LoanType == "hypoteka")
        {
            foreach (var item in _fch.FinHypotekaAll)
            {
                itt = new ddLoanTypeData();
                itt.LoanId = item.id.ToString();
                itt.LoanName = item.Nazov;
                dd.Add(itt);
            }
            return dd;
        }
        if (LoanType == "spotrebyuver")
        {
            List<string> aa = (from a in _fch.FinSuAll select a.Nazov).Distinct().ToList();

            foreach (var item in aa)
            {
                itt = new ddLoanTypeData();
                itt.LoanId = item;
                itt.LoanName = item;
                dd.Add(itt);
            }
            return dd;

        }
        dd.Add(itt);
        return dd;
    }
    [System.Web.Services.WebMethod]
    public static List<ddLoanTypeData> GetLoanTypes(string LoanCategory, String LoanType)
    {
        ddLoanTypeData itt = new ddLoanTypeData();
        List<ddLoanTypeData> dd = new List<ddLoanTypeData>();
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        if (LoanType == "hypoteka")
        {
            for (int i = 0; i < 20; i++)
            {
                itt = new ddLoanTypeData();
                itt.LoanId = ((i + 1) * _fch.FinHypotekaAll.FirstOrDefault().VyskaUveru ?? 0).ToString("# ##0");
                itt.LoanName = ((i + 1) * _fch.FinHypotekaAll.FirstOrDefault().VyskaUveru ?? 0).ToString("# ##0");
                dd.Add(itt);
            }
            return dd;
        }
        if (LoanType == "spotrebyuver")
        {
            var loanTypeData = from a in _fch.FinSuAll where a.Nazov == LoanCategory select a;

            foreach (var item in loanTypeData)
            {
                itt = new ddLoanTypeData();
                itt.LoanId = item.id.ToString();
                itt.LoanName = (item.VyskaUveru ?? 0).ToString("# ##0");
                dd.Add(itt);
            }
            return dd;

        }
        dd.Add(itt);
        return dd;
    }
    [System.Web.Services.WebMethod]
    public static List<ddLoanTypeDetail> CalculateLoans(string LoanCategory, String LoanType, string loanAmount)
    {
        ddLoanTypeDetail itt = new ddLoanTypeDetail();
        List<ddLoanTypeDetail> dd = new List<ddLoanTypeDetail>();
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        if (LoanType == "hypoteka")
        {
            var aa = (from a in _fch.FinHypotekaAll where a.id.ToString() == LoanCategory select a).FirstOrDefault();
            decimal amount = Convert.ToDecimal(loanAmount);
            itt = new ddLoanTypeDetail();
            itt.Periods = aa.PocetSplatok.ToString();
            itt.Urok = ((aa.Urok ?? 1) * 100).ToString("0.00") + " %";
            itt.PeriodPrice = ((amount / aa.VyskaUveru) * aa.SplatkaObdobie ?? 1).ToString("# ##0");

            dd.Add(itt);
            return dd;
        }
        if (LoanType == "spotrebyuver")
        {
            var loanTypeData = from a in _fch.FinSuAll where a.Nazov == LoanCategory select a;

            var aa = (from a in _fch.FinSuAll where a.id.ToString() == loanAmount select a).FirstOrDefault(); //(a.VyskaUveru ?? 1).ToString("0")
            decimal amount = Convert.ToDecimal(loanAmount);
            itt = new ddLoanTypeDetail();
            itt.Periods = aa.ObdobiaSplacania.ToString();
            itt.Urok = ((aa.Urok ?? 1) * 100).ToString("0.00") + " %";
            itt.PeriodPrice = (aa.SplatkaObdobie ?? 1).ToString("# ##0");

            dd.Add(itt);
            return dd;

        }
        dd.Add(itt);
        return dd;
    }

    [System.Web.Services.WebMethod]
    public static string BuyLoan(string session, string LoanCategory, String LoanType, string loanAmount)
    {
        FinCache.FinCache _fch = FinCache.FinCache.GetInstance();
        UserStatus _status = new UserStatus(session);
        FinUvery uv = new FinUvery(_status.ST.CurrentPeriod, session);
        if (LoanType == "hypoteka")
        {
            if (uv.GetSumOFMajetok("Hypoteka") == 0)
            {
                var aa = (from a in _fch.FinHypotekaAll where a.id.ToString() == LoanCategory select a).FirstOrDefault();
                decimal amount = Convert.ToDecimal(loanAmount);
                uv.BuyLoan(aa.Kod, amount, aa.PocetSplatok ?? 0, (amount / aa.VyskaUveru) * aa.SplatkaObdobie ?? 1, "Hypoteka");
                return "1";
            }

        }
        if (LoanType == "spotrebyuver")
        {
            if (uv.GetSumOFMajetok("Uver") == 0)
            {
                var loanTypeData = from a in _fch.FinSuAll where a.Nazov == LoanCategory select a;
                var aa = (from a in _fch.FinSuAll where a.id == int.Parse(loanAmount) select a).FirstOrDefault();
                decimal amount = Convert.ToDecimal(loanAmount);

                uv.BuyLoan(aa.Kod, aa.VyskaUveru ?? 0, aa.ObdobiaSplacania ?? 0, aa.SplatkaObdobie ?? 2, "Uver");
                return "1";
            }
        }
        return "0";

    }



    public struct ddLoanTypeData
    {
        public string LoanName;
        public String LoanId;
    }
    public struct ddLoanTypeDetail
    {
        public string Urok;
        public string Periods;
        public String PeriodPrice;
    }
}