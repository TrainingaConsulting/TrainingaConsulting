﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Setup : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnUdalosti_Click(object sender, EventArgs e)
    {
        Response.Redirect("Udalosti.aspx");
    }
    protected void btnAkcie_Click(object sender, EventArgs e)
    {
        Response.Redirect("Akcie.aspx");
    }
    protected void btnCiele_Click(object sender, EventArgs e)
    {
        Response.Redirect("Ciele.aspx");
    }
    protected void btnDlhopisy_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dlhopisy.aspx");
    }
    protected void BtnPodieloveFondy_Click(object sender, EventArgs e)
    {
        Response.Redirect("PodieloveFondy.aspx");
    }
    protected void btnHypoteky_Click(object sender, EventArgs e)
    {
        Response.Redirect("Hypoteky.aspx");
    }
    protected void btnUvery_Click(object sender, EventArgs e)
    {
        Response.Redirect("Uvery.aspx");
    }
    protected void btnPoistenia_Click(object sender, EventArgs e)
    {
        Response.Redirect("Poistenia.aspx");
    }
    protected void btnSporenia_Click(object sender, EventArgs e)
    {
        Response.Redirect("Sporenia.aspx");
    }
}