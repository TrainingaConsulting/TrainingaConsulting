﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UdalostiPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Setup.aspx");
    }
    protected void btnNewRecord_Click(object sender, EventArgs e)
    {
        using (DataClassesSetupDataContext dt = new DataClassesSetupDataContext())
        {
            Udalost s = new Udalost();

            s.Aktivne = false;
            //s.Kod = "DPS";
            //s.ElimKodUdalosti = "0";
            //s.RocnyZisk = 0;
            //s.VkladRok = 0;
            //s.VkladPerioda = 0;
            //s.RocnyZisk = 0;
            dt.Udalosts.InsertOnSubmit(s);

            dt.SubmitChanges();
        }
        Tools.RestartCache();
        Response.Redirect("Udalosti.aspx");
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("Udalosti.aspx");
    }
    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        Tools.RestartCache();
    }
    protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        e.NewValues["Pravdepodobnost"] = e.NewValues["Pravdepodobnost"].ToString().Replace(".", ",");
        e.NewValues["CASHFlowPrijem"] = e.NewValues["CASHFlowPrijem"].ToString().Replace(".", ",");
        e.NewValues["CASHFLOWVydaj"] = e.NewValues["CASHFLOWVydaj"].ToString().Replace(".", ",");
        e.NewValues["MAJETOKPrijem"] = e.NewValues["MAJETOKPrijem"].ToString().Replace(".", ",");
        e.NewValues["MAJETOKVydaj"] = e.NewValues["MAJETOKVydaj"].ToString().Replace(".", ",");
    }
}