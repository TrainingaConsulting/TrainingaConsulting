﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class DlhopisyPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Setup.aspx");
    }
    protected void btnNewRecord_Click(object sender, EventArgs e)
    {
        using (DataClassesSetupDataContext dt = new DataClassesSetupDataContext())
        {
            Dlhopisy s = new Dlhopisy();

            s.Aktivne = false;
            s.Kod = "DPS";
            s.ElimKodUdalosti = "0";
            s.RocnyZisk = 0;
            s.VkladRok = 0;
            s.VkladPerioda = 0;
            s.RocnyZisk = 0;
            dt.Dlhopisies.InsertOnSubmit(s);

            dt.SubmitChanges();
        }
        Tools.RestartCache();
        Response.Redirect("Dlhopisy.aspx");
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("Dlhopisy.aspx");
    }
    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        Tools.RestartCache();
    }
}