﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Uvery : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Setup.aspx");
    }
    protected void btnNewRecord_Click(object sender, EventArgs e)
    {
        using (DataClassesSetupDataContext dt = new DataClassesSetupDataContext())
        {
            SU s = new SU();

            s.Aktivne = false;
            s.Kod = "SU";
            s.ElimKodUdalosti = 0;
            s.RokySplacania = 0;
            dt.SUs.InsertOnSubmit(s);

            dt.SubmitChanges();
        }
        Tools.RestartCache();
        Response.Redirect("Uvery.aspx");
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("Uvery.aspx");
    }
    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        Tools.RestartCache();
    }
}