﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PoisteniaPage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Setup.aspx");
    }
    protected void btnNewRecord_Click(object sender, EventArgs e)
    {
        using (DataClassesSetupDataContext dt = new DataClassesSetupDataContext())
        {
            Poistenia s = new Poistenia();

            s.Aktivne = false;
            s.ElimKodUdalosti = "0";
            s.RocnyZisk = 0;
            dt.Poistenias.InsertOnSubmit(s);

            dt.SubmitChanges();
        }
        Tools.RestartCache();
        Response.Redirect("Poistenia.aspx");
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("Poistenia.aspx");
    }
    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        Tools.RestartCache();
    }
}