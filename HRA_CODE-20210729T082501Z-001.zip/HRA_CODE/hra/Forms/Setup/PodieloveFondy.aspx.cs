﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class PodieloveFondy : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnBack_Click(object sender, EventArgs e)
    {
        Response.Redirect("Setup.aspx");
    }
    protected void btnNewRecord_Click(object sender, EventArgs e)
    {
        using (DataClassesSetupDataContext dt = new DataClassesSetupDataContext())
        {
            OPF o = new OPF();

            o.Aktivne = false;
            o.Kod = "OPF";
            o.ElimKodUdalosti = 0;
            o.VkladPerioda = 0;
            o.VkladRok = 0;
            o.RocnyZisk = 0;
            dt.OPFs.InsertOnSubmit(o);

            dt.SubmitChanges();
        }
        Tools.RestartCache();
        Response.Redirect("PodieloveFondy.aspx");
    }
    protected void btnRefresh_Click(object sender, EventArgs e)
    {
        Response.Redirect("PodieloveFondy.aspx");
    }
    protected void GridView1_RowUpdated(object sender, GridViewUpdatedEventArgs e)
    {
        Tools.RestartCache();
    }
}