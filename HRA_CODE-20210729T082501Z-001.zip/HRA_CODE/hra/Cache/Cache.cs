﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FinCache
{
    public class FinCache
    {
        private static FinCache _instance;
        private static bool _rstrCache = false;
        public static FinCache GetInstance()
        {
            _rstrCache = RestartCache();
            if (null == _instance)
            {
                _instance = new FinCache();
            }
            return _instance;
        }
        private void LoadData()
        {
            using (DataDataContext dt = new DataDataContext())
            {
                
                _FinHypotekaAll = dt.GetAllHypoteka().ToList<Hypoteka>();
                _FinDlhopisAll = dt.GetAllDlhopis().ToList<Dlhopis>();
                _FinAkciaAll = dt.GetAllAkcia().ToList<Akcia>();
                _FinOpfAll  = dt.GetAllOpf().ToList<OPF>();
                _FinSsAll = dt.GetAllSS().ToList<SS>();
                _FinSuAll = dt.GetAllSu().ToList<SU>();
                //_FinUpAll = dt.GetAllUp().ToList<UP>();
                ////_FinUpDistinct = dt.GetDistinctUp().ToList<UP>();
                //_FinZpAll = dt.GetAllZp().ToList<ZP>();
                ////_FinZpDistinct = dt.GetDistinctZp().ToList<ZP>();
                _FinPoistenia = dt.GetAllPoistenia().ToList<Poistenia>();
                _FinDistPoist = dt.GetDistinctPoistenia().ToList<DistinctPoistenia>();
                _FinCiselnik = dt.GetAllCiselnik().ToList<GameCiselnik>();
                _FinSetup = dt.GetAllSetup().ToList<GameSetup>();
                _FinUdalost = dt.GetAllUdalost().ToList<Udalost>();
                _FinCiele = dt.GetAllCiele().ToList<Ciele>();

                SetCacheRestarted();
            }

        }

        private List<Hypoteka> _FinHypotekaAll = null;
        private List<Dlhopis> _FinDlhopisAll = null;
        private List<OPF> _FinOpfAll = null;
        private List<Akcia> _FinAkciaAll = null;
        private List<SS> _FinSsAll = null;
        private List<SU> _FinSuAll = null;
        private List<DistinctPoistenia> _FinDistPoist = null;
        private List<Poistenia> _FinPoistenia = null;
        //private List<UP> _FinUpAll = null;
        //private List<UP> _FinUpDistinct = null;
        //private List<ZP> _FinZpAll = null;
        //private List<ZP> _FinZpDistinct = null;
        private List<GameCiselnik> _FinCiselnik = null;
        private List<GameSetup> _FinSetup = null;
        private List<Udalost> _FinUdalost = null;
        private List<Ciele> _FinCiele = null;

        
        public List<DistinctPoistenia> FinPoisteniaDist
        {
            get
            {
                if (_FinCiele == null | _rstrCache == true)
                {
                    LoadData();
                }
                return _FinDistPoist;
            }
        }
        public List<Poistenia> FinPoisteniaAll
        {
            get
            {
                if (_FinCiele == null | _rstrCache == true)
                {
                    LoadData();
                }
                return _FinPoistenia;
            }
        }
        public List<Ciele> FinCieleAll
        {
            get
            {
                if (_FinCiele == null | _rstrCache == true)
                {
                    LoadData();
                }
                return _FinCiele;
            }
        }
        public List<Hypoteka> FinHypotekaAll
        {
            get
            {
                if (_FinHypotekaAll == null | _rstrCache == true)
                {
                    LoadData();
                }
                return _FinHypotekaAll;
            }
        }
        public List<Dlhopis> FinDlhopisAll
        {
            get
            {
                if (_FinDlhopisAll == null | _rstrCache == true)
                {
                    LoadData();
                }
                return _FinDlhopisAll;
            }
        }
        public List<OPF> FinOpfAll
        {
            get
            {
                if (_FinOpfAll == null | _rstrCache == true)
                {
                    LoadData();
                }
                return _FinOpfAll;
            }

        }
        public List<Akcia> FinAkciaAll
        {
            get
            {
                if (_FinAkciaAll == null | _rstrCache == true)
                {
                    LoadData();
                } return _FinAkciaAll;
            }

        }
        public List<SS> FinSsAll
        {
            get
            {
                if (_FinSsAll == null | _rstrCache == true)
                {
                    LoadData();
                }
                return _FinSsAll;
            }
        }
        public List<SU> FinSuAll
        {
            get
            {
                if (_FinSuAll == null | _rstrCache == true)
                {
                    LoadData();
                }
            return _FinSuAll; }
        }
        //public List<UP> FinUpAll
        //{
        //    get
        //    {
        //        if (_FinUpAll == null | _rstrCache == true)
        //        {
        //            LoadData();
        //        } return _FinUpAll;
        //    }

        //}
        //public List<UP> FinUpDistinct
        //{
        //    get
        //    {
        //        if (_FinUpDistinct == null | _rstrCache == true)
        //        {
        //            LoadData();
        //        } return _FinUpDistinct;
        //    }

        //}
        //public List<ZP> FinZpAll
        //{
        //    get
        //    {
        //        if (_FinZpAll == null | _rstrCache == true)
        //        {
        //            LoadData();
        //        } return _FinZpAll;
        //    }
        //}
        //public List<ZP> FinZpDistinct
        //{
        //    get
        //    {
        //        if (_FinZpDistinct == null | _rstrCache == true)
        //        {
        //            LoadData();
        //        } return _FinZpDistinct;
        //    }
        //}
        public List<GameCiselnik> FinCiselnik
        {
            get
            {
                if (_FinCiselnik == null | _rstrCache == true)
                {
                    LoadData();
                } return _FinCiselnik; 
            }
        }
        public List<GameSetup> FinSetup
        {
            get
            {
                if (_FinSetup == null | _rstrCache == true)
                {
                    LoadData();
                } return _FinSetup;
            }

        }
        public List<Udalost> FinUdalost
        {
            get
            {
                if (_FinUdalost == null | _rstrCache == true)
                {
                    LoadData();
                } return _FinUdalost;
            }
        }


        public GameCiselnik GetCiselnikValue(String CiselnikName)
        {
            GameCiselnik Gmec;

            Gmec = (from a in FinCiselnik
                    where a.Name == CiselnikName
                    select a).FirstOrDefault();

            return Gmec;
        }
        public GameSetup GetSetupValue(String SetupName)
        {
            GameSetup Gset = null;

            Gset = (from a in _FinSetup
                    where a.Name == SetupName
                    select a).FirstOrDefault();

            return Gset;
        }

        public void SetCacheToRestart()
        {
            using (DataDataContext dt = new DataDataContext())
            {
                dt.SetCacheToRestart();
            }
        }
        public void SetCacheRestarted()
        {
            using (DataDataContext dt = new DataDataContext())
            {
                dt.SetCacheRestarted();
            }
        }
        private static bool RestartCache()
        {
            bool ret = false;
            using (DataDataContext dt = new DataDataContext())
            {
                if (dt.RestartCache() == 0)
                {
                    ret = false;
                }
                else
                {
                    ret = true;
                }
            }
            return ret;
        }
    
    }
}
