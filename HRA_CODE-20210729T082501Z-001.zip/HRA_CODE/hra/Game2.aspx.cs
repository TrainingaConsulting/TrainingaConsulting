﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using FinCache;

public partial class Game2 : System.Web.UI.Page
{
    FinCache.FinCache _fch = null;
    FinGame gm = null;
    UserStatus _status = null;
    FinDlhopisy dlh = null;
    FinPodiely pod = null;
    FinAkcie akc = null;
    FinStavebneSporenia SSP = null;
    FinUvery UVR = null;
    FinPoistenia POI = null;

    protected void Page_Init(object sender, EventArgs e)
    {
        // vypnutie cache pre Jquery - opetovne zobrazenie dialogoveho okna by mohlo natahovat povodne hodnoty
        Response.Cache.SetCacheability(System.Web.HttpCacheability.NoCache);
        Response.Cache.SetNoStore();
        hdn1.Value = Session.SessionID;
    }
    protected void Page_Load(object sender, EventArgs e)
    {

        _fch = FinCache.FinCache.GetInstance();
        _status = new UserStatus(Session.SessionID);
        if (_status.ST.Vek > _fch.GetCiselnikValue("MaximalnyVekHraca").IntValue)
        {
            Response.Redirect("GameEnd.aspx");
        }
        dlh = new FinDlhopisy(_status.ST.CurrentPeriod, Session.SessionID);
        pod = new FinPodiely(_status.ST.CurrentPeriod, Session.SessionID);
        akc = new FinAkcie(_status.ST.CurrentPeriod, Session.SessionID);
        SSP = new FinStavebneSporenia(_status.ST.CurrentPeriod, Session.SessionID);
        UVR = new FinUvery(_status.ST.CurrentPeriod, Session.SessionID);
        POI = new FinPoistenia(_status.ST.CurrentPeriod, Session.SessionID);

        gm = new FinGame(Session.SessionID);
        if (!Page.IsPostBack)
        {
            _status = gm._user;
            if (_status.ST != null)
            {
                refreshFields();
            }
        }
        CheckMajetok();
        
        
    }


    private void refreshFields()
    {
        lblDoVeku.Text = _fch.GetCiselnikValue("MaximalnyVekHraca").IntValue.ToString();
        lblFreeCashFlow.Text = (_status.ST.CashFlow ?? 0).ToString("# ##0");
        lblExpenses.Text = (_status.ST.Vydaje ?? 0).ToString("# ##0");
        lblRental.Text = (_status.ST.Najomne ?? 0).ToString("# ##0");
        lblAge.Text = _status.ST.Vek.ToString();
        lblChildren.Text = _status.ST.PocetDeti.ToString();
        lblCiel1.Text = _status.ST.Ciel1;
        lblCiel2.Text = _status.ST.Ciel2;
        lblCiel3.Text = _status.ST.Ciel3;
        hdnTarget1.Value = _status.ST.Ciel1Id.ToString();
        hdnTarget2.Value = _status.ST.Ciel2Id.ToString();
        hdnTarget3.Value = _status.ST.Ciel3Id.ToString();
        lblPerioda.Text = _status.ST.CurrentPeriod.ToString();
        lblCiel1Cena.Text = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(hdnTarget1.Value)).FirstOrDefault().Price ?? 0).ToString("# ##0");
        lblCiel2Cena.Text = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(hdnTarget2.Value)).FirstOrDefault().Price ?? 0).ToString("# ##0");
        lblCiel3Cena.Text = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(hdnTarget3.Value)).FirstOrDefault().Price ?? 0).ToString("# ##0");

        lblPodielovy.Text = pod.GetNumberOFMajetok();
        LblDlhopisovy.Text = dlh.GetNumberOFMajetok();
        lblAkcie.Text = akc.GetNumberOFMajetok();
        lblSS.Text = SSP.GetNumberOFMajetok();
        lblHypoteka.Text = UVR.GetNumberOFMajetok("HP");
        lblSU.Text = UVR.GetNumberOFMajetok("SU");
        lblUP.Text = POI.GetNumberOFMajetok("Urazove");
        lblZP.Text = POI.GetNumberOFMajetok("Zivotne");


    }
    protected void btnNext_Click(object sender, EventArgs e)
    {

        FinGame gm = new FinGame(Session.SessionID);


        gm.NextPeriod();
        gm.AddStatuses();

        FinanceManager mgr = new FinanceManager(Session.SessionID);

        mgr.recalcMajetok();
        mgr.recalcUdalosti();

        _status = gm._user;
        _status = new UserStatus(Session.SessionID);
        if (_status.ST != null)
        {
            refreshFields();
            _status.ST.PopupSwitcher = _status.ST.CurrentPeriod;
            _status.ST.InfoSwitcher = _status.ST.CurrentPeriod;
            hndPrd.Value = _status.ST.CurrentPeriod.ToString();
        }
    }
    [System.Web.Services.WebMethod]
    public static string PopupSwitcher(string session)
    {
        String ret = "false";
        UserStatus _status = new UserStatus(session);
        ret = _status.ST.PopupSwitcher.ToString();
        if (_status.ST.CurrentPeriod == _status.ST.PopupSwitcher)
        {
            _status.ST.PopupSwitcher++;
            _status.SaveUserStatus();
            ret = "true";
        }
        if (_status.ST.CurrentPeriod == 0)
        {
            ret = "false";
        }
        return ret;
    }
    

    [System.Web.Services.WebMethod]
    public static string InfoSwitcher(string session)
    {
        String ret = "false";
        UserStatus _status = new UserStatus(session);
        ret = _status.ST.InfoSwitcher.ToString();
        if (_status.ST.CurrentPeriod == _status.ST.InfoSwitcher)
        {
            _status.ST.InfoSwitcher++;
            _status.SaveUserStatus();
            ret = "true";
        }
        if (_status.ST.CurrentPeriod == 0)
        {
            ret = "false";
        }
        return ret;
    }

    [System.Web.Services.WebMethod]
    public static string recalc( string session)
    {
        String ret = "nie";
        Udalosti ud = new Udalosti(session);
        ud.ProcessCurrentUdalost();
        return ret;
    }
    #region Ciele
    protected void btnBuy1_Click(object sender, EventArgs e)
    {
        _status = new UserStatus(Session.SessionID);
        _fch = FinCache.FinCache.GetInstance();
        if (!_status.ST.SplnenyCiel1)
        {
            decimal price = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(hdnTarget1.Value)).FirstOrDefault().Price ?? 0);
            _status.ST.CashFlow = _status.ST.CashFlow - price;
            _status.ST.SplnenyCiel1 = true;
            _status.SaveUserStatus();
            RedirectToPage();
        }
    }


    protected void btnBuy2_Click(object sender, EventArgs e)
    {
        _status = new UserStatus(Session.SessionID);
        _fch = FinCache.FinCache.GetInstance();
        if (!_status.ST.SplnenyCiel2)
        {
            decimal price = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(hdnTarget2.Value)).FirstOrDefault().Price ?? 0);
            _status.ST.CashFlow = _status.ST.CashFlow - price;
            _status.ST.SplnenyCiel2 = true;
            _status.SaveUserStatus();
            RedirectToPage();
        }
    }
    protected void btnBuy3_Click(object sender, EventArgs e)
    {
        _status = new UserStatus(Session.SessionID);
        _fch = FinCache.FinCache.GetInstance();
        if (!_status.ST.SplnenyCiel3)
        {
            decimal price = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(hdnTarget3.Value)).FirstOrDefault().Price ?? 0);
            _status.ST.CashFlow = _status.ST.CashFlow - price;
            _status.ST.SplnenyCiel3 = true;
            _status.SaveUserStatus();
            RedirectToPage();
        }
    }
    protected void btnSell1_Click(object sender, EventArgs e)
    {
        _status = new UserStatus(Session.SessionID);
        _fch = FinCache.FinCache.GetInstance();
        if (_status.ST.SplnenyCiel1)
        {
            decimal price = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(hdnTarget1.Value)).FirstOrDefault().Price ?? 0);
            _status.ST.CashFlow = _status.ST.CashFlow + price;
            _status.ST.SplnenyCiel1 = false;
            _status.SaveUserStatus();
            if (!Tools.HracMaMajetok(_status.ST.SessionID, _fch, 1))
            {
                CancelMortage(_status, _fch);
            }
            Response.Redirect("Game.aspx");
        }
    }
    protected void btnSell2_Click(object sender, EventArgs e)
    {
        _status = new UserStatus(Session.SessionID);
        _fch = FinCache.FinCache.GetInstance();
        if (_status.ST.SplnenyCiel2)
        {
            decimal price = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(hdnTarget2.Value)).FirstOrDefault().Price ?? 0);
            _status.ST.CashFlow = _status.ST.CashFlow + price;
            _status.ST.SplnenyCiel2 = false;
            _status.SaveUserStatus();
            if (!Tools.HracMaMajetok(_status.ST.SessionID, _fch, 1))
            {
                CancelMortage(_status, _fch);
            }
            Response.Redirect("Game.aspx");
        }
    }
    protected void btnSell3_Click(object sender, EventArgs e)
    {
        _status = new UserStatus(Session.SessionID);
        _fch = FinCache.FinCache.GetInstance();
        if (_status.ST.SplnenyCiel3)
        {
            decimal price = (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == int.Parse(hdnTarget3.Value)).FirstOrDefault().Price ?? 0);
            _status.ST.CashFlow = _status.ST.CashFlow + price;
            _status.ST.SplnenyCiel3 = false;
            _status.SaveUserStatus();
            if (!Tools.HracMaMajetok(_status.ST.SessionID, _fch, 1))
            {
                CancelMortage(_status, _fch);
            }
            Response.Redirect("Game.aspx");
        }
    }
    private bool IsMajetok(int MajetokId)
    {
        bool ret = false;

        if (_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == MajetokId).FirstOrDefault().Type == "Nehnuteľnost")
        {
            ret = true;
        }
        return ret;
    }
    private bool HasMoney(int MajetokId)
    {
        bool ret = false;

        if ((_fch.FinCieleAll.Select(m => m).Where(mo => mo.id == MajetokId).FirstOrDefault().Price ?? 0) <= (_status.ST.CashFlow ?? 1))
        {
            ret = true;
        }
        return ret;
    }
    private void RedirectToPage()
    {
        if (_status.ST.SplnenyCiel1 & _status.ST.SplnenyCiel2 & _status.ST.SplnenyCiel3)
        {
            Response.Redirect("GameEnd.aspx");
        }
        else
        {
            Response.Redirect("Game.aspx");
        }
    }


    private void CancelMortage(UserStatus User, FinCache.FinCache FinCache)
    {
        FinCache.FinCache _fch = FinCache;
        UserStatus _status = User;
        
        using (DataClassesDataContext dt = new DataClassesDataContext())
        {
            var _majetok = dt.GetUserMajetok(_status.ST.SessionID).ToList<Majetok>();
            var mylist = _majetok.Select(m => m).Where(mo => mo.Name == "Hypoteka");
            if (mylist != null)
            {
                if (mylist.Count() > 0)
                {
                    foreach (var item in mylist)
                    {
                        var aa = (from a in dt.Majetoks
                                  where a.id == item.id
                                  select a).FirstOrDefault();
                        aa.Active = false;
                        aa.Sold = true;

                        _status.ST.CashFlow = _status.ST.CashFlow - (Math.Abs(aa.PeriodCFChange ?? 1) * aa.PeriodDuration);
                        _status.SaveUserStatus();

                        aa.PeriodDuration = 0;
                        dt.SubmitChanges();
                    }
                }
            }

        }

    }

    public void CheckMajetok()
    {
        //_status = new UserStatus(Session.SessionID);
        //_fch = FinCache.FinCache.GetInstance();
        if (_status.ST.SplnenyCiel1)
        {
            btnBuy1.Visible = false;
            if (IsMajetok(int.Parse(hdnTarget1.Value)))
            {
                btnSell1.Visible = true;
            }
        }
        else
        {
            if (HasMoney(int.Parse(hdnTarget1.Value)))
            {
                btnBuy1.Visible = true;
            }
            btnSell1.Visible = false;
        }
        if (_status.ST.SplnenyCiel2)
        {
            btnBuy2.Visible = false;
            if (IsMajetok(int.Parse(hdnTarget2.Value)))
            {
                btnSell2.Visible = true;
            }
        }
        else
        {
            if (HasMoney(int.Parse(hdnTarget2.Value)))
            {
                btnBuy2.Visible = true;
            }
            btnSell2.Visible = false;
        }
        if (_status.ST.SplnenyCiel3)
        {
            btnBuy3.Visible = false;
            if (IsMajetok(int.Parse(hdnTarget3.Value)))
            {
                btnSell3.Visible = true;
            }
        }
        else
        {
            if (HasMoney(int.Parse(hdnTarget3.Value)))
            {
                btnBuy3.Visible = true;
            }
            btnSell3.Visible = false;
        }
    }
    #endregion

}
